

/**
 * @description Window on load.
 */
$(window).on("load", (ev) => {});


/**
 * @description Window on resize.
 */
$(window).on("resize", (ev) => {});


/**
 * @description Window on scroll.
 */
$(window).on("scroll", (ev) => {});

