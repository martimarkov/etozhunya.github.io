

/**
 * @name initSvg4everybody
 *
 * @description SVG for Everybody adds external spritemaps support to otherwise SVG-capable browsers.
 */
const initSvg4everybody = () => {

  svg4everybody();

};
