  	$('.slick-carousel').slick({
  		dots:true,
 		centerMode: true,
    	slidesToShow: 1,
    	fade: true,
  	});