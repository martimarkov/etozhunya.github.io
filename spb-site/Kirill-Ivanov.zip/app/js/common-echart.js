/*Dashboard Init*/
 
"use strict"; 

/*****E-Charts function start*****/
var echartsConfig = function() { 
  if( $('#e_chart_1').length > 0 ){
    var eChart_1 = echarts.init(document.getElementById('e_chart_1'));
    var eChart_6 = echarts.init(document.getElementById('e_chart_6'));

    //data
    var data = [220, 182, 191, 234, 190, 330, 310];
    var markLineData = [];
    for (var i = 1; i < data.length; i++) {
      markLineData.push([{
        xAxis: i - 1,
        yAxis: data[i - 1],
        value: (data[i] + data[i-1]).toFixed(2)
      }, {
        xAxis: i,
        yAxis: data[i]
      }]);
    }

    //option
    var option = {
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(33,33,33,1)',
        borderRadius:0,
        padding:10,
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: 'rgba(33,33,33,1)'
          }
        },
        textStyle: {
          color: '#fff',
          fontStyle: 'normal',
          fontWeight: 'normal',
          fontFamily: "'Montserrat', sans-serif",
          fontSize: 12
        } 
      },
      color: ['#EF5EB4'], 
      grid:{
        show:false,
        top: 100,
        bottom: 10,
        containLabel: true,
      },
      xAxis: {
        data: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        axisLine: {
          show:false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
      },
      yAxis: {
        axisLine: {
          show:false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
        splitLine: {
          show: false,
        },
      },
      series: [{
        type: 'line',
        data:data,
        markPoint: {
          data: [
            {type: 'max', name: '最大值'},
            {type: 'min', name: '最小值'}
          ]
        },
        markLine: {
          smooth: true,
              effect: {
                show: true
              },
              distance: 10,
          label: {
            normal: {
              position: 'middle'
            }
          },
          symbol: ['none', 'none'],
          data: markLineData
        }
      }]
    };
    eChart_1.setOption(option);
    eChart_6.setOption(option);
    eChart_1.resize();
  }
  if( $('#e_chart_2').length > 0 ){
    var eChart_2 = echarts.init(document.getElementById('e_chart_2'));
    var option1 = {
      animation: false,
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(33,33,33,1)',
        borderRadius:0,
        padding:10,
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: 'rgba(33,33,33,1)'
          }
        },
        textStyle: {
          color: '#fff',
          fontStyle: 'normal',
          fontWeight: 'normal',
          fontFamily: "'Montserrat', sans-serif",
          fontSize: 12
        } 
      },
      color: ['#2196F3'], 
      grid: {
        top: 60,
        left:40,
        bottom: 30
      },
      xAxis: {
        type: 'value',
        position: 'top',
        axisLine: {
          show:false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
        splitLine: {
          show:false
        },
      },
      yAxis: {
        splitNumber: 25,
        type: 'category',
        axisLine: {
          show:false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
        axisTick: {
          show: true
        },
        splitLine: {
          show:false
        },
        data: ['Oct', 'Sep', 'Aug', 'July', 'June', 'May', 'Apr', 'Mar', 'Feb', 'Jan']
      },
      series: [{
        name: 'emp',
        type: 'bar',
        barGap: '-100%',
        label: {
          normal: {
            textStyle: {
              color: '#682d19'
            },
            position: 'left',
            show: false,
            formatter: '{b}'
          }
        },
        itemStyle: {
          normal: {
            color: '#2196F3',
          }
        },
        data: [190, 102, 160, 200, 110, 180, 280, 140, 220, 300]
      }, {
        type: 'line',
        silent: true,
        barGap: '-100%',
        data: [100, 100, 400, 170, 200, 300, 100, 200, 120, 200],
        itemStyle: {
          normal: {
            color: '#f7ce99',

          }
        },

      }]
    }
    eChart_2.setOption(option1);
    eChart_2.resize();
  }
  if( $('#e_chart_3').length > 0 ){
    var eChart_3 = echarts.init(document.getElementById('e_chart_3'));
    var option3 = {
      color: ['#2196F3', '#00a5d1', '#57bce1', '#f7ce99'],
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(33,33,33,1)',
        borderRadius:0,
        padding:10,
        axisPointer: {
          type: 'cross',
          label: {
            backgroundColor: 'rgba(33,33,33,1)'
          }
        },
        textStyle: {
          color: '#fff',
          fontStyle: 'normal',
          fontWeight: 'normal',
          fontFamily: "'Montserrat', sans-serif",
          fontSize: 12
        } 
      },
      xAxis: {
        type: 'category',

        boundaryGap: false,
        splitLine: {
          show: false
        },
        axisLine: {
          show:false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
        "splitArea": {
          "show": false
        },
        
        data: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12']
      },
      grid: {
        left: '6%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      yAxis: {
        axisLine: {
          show: false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
        splitLine: {
          show: false,
        },
      },
      series: [{
          name: 'A',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 4,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 0
            }
          },
          areaStyle: {
            normal: {
              opacity: "1",
            }
          },
          data: [0, -7.5, -1.0, 3.7, 0, -3, 8, 0,-3.6, 4, -2, 0]
        },

        {
          name: 'B',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 4,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 0
            }
          },
          areaStyle: {
            normal: {
              opacity: "1",
            }
          },
          data: [0, -2.2, 2, -2.2, 0, -1.5, 0, 2.4, -1, 3, -1, 0]
        }, {
          name: 'C',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 4,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 0
            }
          },
          areaStyle: {
            normal: {
              opacity: "1",
            }
          },
          data: [0, 2.3, 0, 1.2, -1, 3, 0, -3.3, 0, 2, -0.3, 0]
        },

        {
          name: 'D',
          type: 'line',
          smooth: true,
          symbol: 'circle',
          symbolSize: 4,
          showSymbol: false,
          lineStyle: {
            normal: {
              width: 0
            }
          },
          areaStyle: {
            normal: {
              opacity: "1",
            }
          },
          data: [0, 10, 0.13,2,0, 2, 0, 3.7, 0, 1, -3, 0]
        }
      ]
    };
    eChart_3.setOption(option3);
    eChart_3.resize();
  }
  if( $('#e_chart_4').length > 0 ){
    var eChart_4 = echarts.init(document.getElementById('e_chart_4'));
    var data = [];
    for (var i = 0; i <= 10; i++) {
      var theta = i / 100 * 360;
      var r = 5 * (1 + Math.sin(theta / 180 * Math.PI));
      data.push([r, theta]);
    }
    var option4 = {
      polar: {},
      tooltip: {
        trigger: 'axis',
        backgroundColor: 'rgba(33,33,33,1)',
        borderRadius:0,
        padding:10,
        textStyle: {
          color: '#fff',
          fontStyle: 'normal',
          fontWeight: 'normal',
          fontFamily: "'Montserrat', sans-serif",
          fontSize: 12
        } 
      },
      angleAxis: {
        type: 'value',
        startAngle: 0,
        axisLine: {
          lineStyle: {
            color: 'rgba(33, 33, 33, 0.1)'
          }
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
      },
      radiusAxis: {
        axisLine: {
          lineStyle: {
            color: 'rgba(33, 33, 33, 0.1)'
          }
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
      },
      series: [{
        coordinateSystem: 'polar',
        name: 'line',
        type: 'line',
        lineStyle: {
          normal: {
            color: '#2196F3',
          }
        },
        itemStyle: {
          normal: {
            color: '#2196F3',
          }
        },
         areaStyle: {
          normal: {
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
               offset: 0,
               color: '#2196F3'
               }, {
               offset: 1,
               color: '#00a5d1'
            }])
          }
          },
        
        data: data
      }]
    };
    eChart_4.setOption(option4);
    eChart_4.resize();
  }
    if( $('#e_chart_5').length > 0 ){
  var eChart_5 = echarts.init(document.getElementById('e_chart_5'));
  var xData = function(){
    var data = [];
    for(var i=1;i<6;i++){
     data.push(i);   
    }
    return data;
  }();

  var option5 = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(33,33,33,1)',
      borderRadius:0,
      padding:10,
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: 'rgba(33,33,33,1)'
        }
      },
      textStyle: {
        color: '#fff',
        fontStyle: 'normal',
        fontWeight: 'normal',
        fontFamily: "'Montserrat', sans-serif",
        fontSize: 12
      } 
    },
    "grid": {
      show:false,
      top: 30,
      bottom: 10,
      containLabel: true,
    }, 
    "legend": {
      "x": "right", 
      "data": [ ]
    }, 
    "calculable": true, 
    "xAxis": [
      {
        type: "category", 
        splitLine: {
          "show": false
        }, 
        axisLine: {
          show:false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
        axisTick: {
          "show": false
        }, 
        splitArea: {
          "show": false
        }, 
        data: xData,
      }
    ], 
    "yAxis": [
      {
        type: "value", 
        splitLine: {
          "show": false
        }, 
        axisLine: {
          show:false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        },
        axisTick: {
          "show": false
        }, 
        splitArea: {
          "show": false
        }
      }
    ], 
    "series": [
      {
        "name": "male", 
        "type": "bar", 
        "stack": "split", 
        "barMaxWidth": 50, 
        "barGap": "10%", 
        "itemStyle": {
          "normal": {
            "barBorderRadius": 0, 
            "color": '#a169ef', 
            "label": {
              "show": true, 
              "textStyle": {
                "color": "#fff"
              }, 
              "position": "insideTop",
              formatter : function(p) {
                return p.value > 0 ? (p.value ): '';
              }
            }
          }
        }, 
        "data": [
          370, 
          241, 
          755, 
          555, 
          260, 
        ], 
      }, 
      {
        "name": "female", 
        "type": "bar", 
        "stack": "split", 
        "itemStyle": {
          "normal": {
            "color": '#f742aa', 
            "barBorderRadius": 0, 
            "label": {
              "show": true, 
              "position": "top",
              formatter : function(p) {
                return p.value > 0 ? ('▼'
                    + p.value + '')
                    : '';
              }
            }
          }
        }, 
        "data": [
          386, 
          20, 
          122, 
          261, 
          171, 
        ]
      }, 
    ]
  }
  eChart_5.setOption(option5);
  eChart_5.resize();
  } 
}
/*****E-Charts function end*****/

/*****Resize function start*****/
var echartResize;
$(window).on("resize", function () {
  /*E-Chart Resize*/
  clearTimeout(echartResize);
  echartResize = setTimeout(echartsConfig, 200);
}).resize(); 
/*****Resize function end*****/

/*****Function Call start*****/
echartsConfig();
/*****Function Call end*****/