(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.pack = function() {
	this.initialize(img.pack);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,176);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AmlHRQANgFApggQAngfAPgFQAagIBLg/QBRhFAQgJQBOgqAkgUQA6ggA0ghQAIgGAsgkQAigdAVgGQAFgCAKgRQAKgQAGgBQAegEAigWQAmgbAVgNQAlgVAIgKQAPgSgQgcQgHgNgTgXQgVgcgGgIQgMgSgbgfIgYgbQhYhShtg5QglgSgNgFQgfgNgVgBQgNAAgPAIQgSAKgKAFQgzAagbAJQgaAKgOAJQgPAJgSAVQgLAMgQAIQgLAFgXAIQgeAKgtAXQg6AfgPAH");
	this.shape.setTransform(-25.5688,27.7087,1.3999,1.3999);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AirC+QgBAABWgkQBegsAngmQAFgFAKgUIAIgTQAegPAIgpQAFguAHgMQACgEAdgfQAWgXgBgUQAAgVgfgDQgUgCgcAFQgWADgNAQQgJAJgQAYQgEAFgLAFQgMAEgDAHQgBADgJAlQgHAcgKAD");
	this.shape_1.setTransform(56.1938,-19.5085,1.3999,1.3999);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ADBAwQgQgBgbgJQghgMgTgGQgXgIgmgFQg9gHgDAAQhKgPgkgGQgWgDgKgEQgTgHgFgM");
	this.shape_2.setTransform(17.2413,-48.7618,1.3999,1.3999);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ADBBYQARgagNgbQgLgWgXgMQgFgCgVgFQgRgFgHgGQgEgEgJgMQgHgKgHgFQgPgNgbgDQghgDgJgEQgagLgLgDQgOgDgaABQgsACgWAEQgsAHgQAS");
	this.shape_3.setTransform(29.3247,-65.6483,1.3999,1.3999);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgWgZQgMAMAHARQAHAQAPAFQAQAEAKgKQADgEAHgP");
	this.shape_4.setTransform(62.7321,-74.6357,1.3999,1.3999);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AARgZQAPAEAAALQAAAKgLAKQgaAcgagU");
	this.shape_5.setTransform(25.8871,-85.3813,1.3999,1.3999);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AATgcQAKgEAKAEQALADACAKQACAJgMALQgFAFgPALQgQALgUgBQgWgBgPgN");
	this.shape_6.setTransform(46.7289,-84.0164,1.3999,1.3999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ABTgsQg3AHgqASQhCAagCAm");
	this.shape_7.setTransform(12.1317,-79.21,1.3999,1.3999);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ABsgeQhAgIgcgBQgYgBgSAMQgIAFgIALQgMAOgDADQgGAGgWAKQgSAJgEAK");
	this.shape_8.setTransform(30.5752,-84.4363,1.3999,1.3999);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ACBAXQgXgngpgUQgvgYggAdQgJAJgsAsQgqAmgTgR");
	this.shape_9.setTransform(49.8587,-85.9453,1.3999,1.3999);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhshrIA1gmQAJgGAPgEQAUgGAEgCQAdgMAgAJQAgAJAUAbQAFAGgCAJQgBAIgGAGQglAhgJAHQgJAHgMAGQgQAHgIADQgdAPgYAnQgVAjgHAnQgOA/gFAS");
	this.shape_10.setTransform(69.3063,-59.3211,1.3999,1.3999);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ACfB2QhShnhjhFQhYg9gwgC");
	this.shape_11.setTransform(-31.0198,-7.1842,1.3999,1.3999);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ADJCqQhQiEhuhcQhMhCg+gZQgWgKgQgGQgdgLgGAE");
	this.shape_12.setTransform(-22.6205,-2.4486,1.3999,1.3999);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAMgbQgJAFgFAVQgHAZgCAE");
	this.shape_13.setTransform(-16.391,-40.1173,1.3999,1.3999);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ADECcQgLgMgPgdQgQgegLgMQghgjg6gpQglgbgxgNQgxgNgvADQgXAHgPADQgbAHABgPQAAgFAIgMQAJgMAMgJQAFgFAMggQALgdAIAA");
	this.shape_14.setTransform(11.2212,-37.878,1.3999,1.3999);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAngfQAPA0gwAKQgSAEgPgJQgPgJAAgR");
	this.shape_15.setTransform(46.0957,-52.8719,1.3999,1.3999);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAQglQgOAJgJAbQgJAWABAR");
	this.shape_16.setTransform(7.9247,-68.9556,1.3999,1.3999);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AANgeQAEAQgJASQgIATgOAI");
	this.shape_17.setTransform(24.6622,-68.5706,1.3999,1.3999);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAQgbQgbAcgFAc");
	this.shape_18.setTransform(40.7594,-61.221,1.3999,1.3999);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ACHB0QgGgDgOgMQgQgOgDgCQgNgKgbgHQgGgBgmgIQhKgRgmgIQgPgEgcgCQgegDgOgCQgVgFgLgNQgKgOAHgUQAFgOAYgdIAXgZQATgJAegDQAQgCAggEQAkgFAQABQAiABAEAYQA9gJAbAWQAHAGAJAQQAHAMANAEQAfAIABAAQARAGALANQAsAzgiAzIgbAVQgfAUgSgLg");
	this.shape_19.setTransform(24.5222,-58.6297,1.3999,1.3999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-85.6,-93.7,171.3,187.5);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pack();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,500,176);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pack();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,500,176);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ay5PEIgG+HMAl/AAAIAAeHg");
	mask.setTransform(125.3,96.425);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AkGAAQAtgBBeADQBVAEA1gDQCOgGBqAA");
	this.shape.setTransform(217.4,10.2481);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhqBhQAYgQBZhYQBVhTAPgG");
	this.shape_1.setTransform(180.375,19.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ACRAFQgVAAh8gFQhvgGghAD");
	this.shape_2.setTransform(14.9,13.0382);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAxBMQgPgMgihAQgghAgQgL");
	this.shape_3.setTransform(34.35,21.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AB5gCQhjACg7AAQgaAAgRAAQgggBgIAE");
	this.shape_4.setTransform(51.1,28.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AghgNQAHADAbAMQAYALAJAB");
	this.shape_5.setTransform(67.4,29.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AnyAIIBpgBQBzgCA4gEQBAgEBMAAQAsAABeABQABAACKgDQBagDAwAIQAYADA8gCQA9gCAVgG");
	this.shape_6.setTransform(119.85,30.425);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhtAsIAAhRQACgGALgBQADAAAXACQAFAMABAVQABAJABAXIAdAAQADAMAAABQADAHAGAAQACgKgBgPQAAgSAAgGQASABAZgEIAEA0IASgBQABgEgCgUQgDgSACgEQACgDAYgCQAMAAALAAIARACIABATQAAAVgBAJ");
	this.shape_7.setTransform(147.6563,124.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AixBSQABgEgBgUQAAgaAAgHQAXgCAEAAQADAIAAAOQABASAAAEIAVAAQgBgCAAgFQgBgFAAgCQAQgDAQgEIgDgpQADAAALgDQAJgBAGAAQAEAPAAAeQADAAAHABQAHAAACgBQgFg3ABgWQAKgCAeADQACAFACAoQA5gFABADQgEg4AAgTQALADABgHQAAgKABAAQAFgEANAAQAHgBANAAQANgBAuADQABAHABALQAPgCACAeQABAPgCAaQAAAKACAbQABAYgDAB");
	this.shape_8.setTransform(116.2143,121.4607);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgrAuQAEgdgEgTQACgBAGAAQAFAAADgBQgCgKAAgPIABgNIAJgCQAKgCACABIABAaQAAADAbgDQAAACABAFQABAEgBACQAGAAAKACQABAEABATQABARADAD");
	this.shape_9.setTransform(90.15,125.58);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgrgWIAogDQABAGgBATQgBAQACAIQAIADAIgDQgBgHgCgfQACgBAGgBQAGgCADAAQACAFABAWQADAUAJgF");
	this.shape_10.setTransform(35.45,124.7068);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ah1AtIAAgkQA0gJCCgdQAQgDAlgM");
	this.shape_11.setTransform(228.7,86.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AABkkQACgEgCCNQAAAhgBAuQgBCLABArQABASgBAmQAAAjAAAVQACAZgCAy");
	this.shape_12.setTransform(216.7958,120.7195);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiCgeQAyAPA1ANQALACAaACQAYACAOAEQAOAFAaAMQAYAJAUgG");
	this.shape_13.setTransform(229.95,153.058);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgIGBQAAgxAIlQQAJlUAAgs");
	this.shape_14.setTransform(190.2,48.575);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiEgJQAPgCBuAMICMAJ");
	this.shape_15.setTransform(202.85,108.267);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiEAAQAEAAAugBQAxgCAcACQARABA0ABQAzACASAB");
	this.shape_16.setTransform(202.825,111.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiLAOQACgCAaAAQAigBALgBQAZgCAsgGQAhgCBogM");
	this.shape_17.setTransform(202.75,138.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiNAJQAyACBbgJQBlgKApAA");
	this.shape_18.setTransform(202.175,135.5424);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAAhBQAABJABA6");
	this.shape_19.setTransform(188.5,147.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAGiNQgJBBAACDQAAABgBArQgBAaACAR");
	this.shape_20.setTransform(188.9357,125.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AABhkQgBAEAAAwQAAAtABAeQAAAHgBAdQAAAWABAQ");
	this.shape_21.setTransform(189.45,101.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiJgVQAjACA9AMQA7ALAZAEQAOACAsAGQAfAEAGAC");
	this.shape_22.setTransform(203.25,93.425);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiKgTQAlADBfAQQBjAPAtAF");
	this.shape_23.setTransform(203.05,89.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AjkgZQAjAHBLAXQBDAVABgBQAZgIApgGQAYgDAtgGQAQgCA4gHQAtgFAbgG");
	this.shape_24.setTransform(193.875,151.8506);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhmgUQAMgCAXAJQAaAJAIABQAgADAtAJQA5AMACAA");
	this.shape_25.setTransform(177.925,138.1638);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhngRQAgAABHARQBHASAhAA");
	this.shape_26.setTransform(177.775,134.6507);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhrAQQANABAVgFQAMgDAXgGIBCgKQBEgMAMAF");
	this.shape_27.setTransform(178.825,113.3219);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhuAXQAGABAugNQATgFAngHQAKgCAugHQAjgGAUgG");
	this.shape_28.setTransform(178.55,109.3759);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAAgUIABAp");
	this.shape_29.setTransform(189.4,89.15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhjArQA7gXADgBQAlgQAYgMQAUgKA4gY");
	this.shape_30.setTransform(179.3,91.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhpAtQALgCARgJQAZgNADgBQAJgEAUgIQATgHAKgEIA7gbQAKgFAdgJ");
	this.shape_31.setTransform(178.45,95.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAIikQAAAxACBjQAAAVAAABQgDAHgQgBQAAABABAPQABAKABAGQACgBAEABQAEABACgBQAAAIABAhQAAAaAAAOIgCAo");
	this.shape_32.setTransform(168.325,131.65);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgJhaQgCAFACANQACANgCAFQAEgBAOgGQADA8gCA3QgDAAgGACQgGACgDAAQADAKABAW");
	this.shape_33.setTransform(168.3146,105.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAMlPQgHAYABC0QABBcABBwQgBAXAAB0QAAAPAAAdQABAbgCARQgCAUAEAFQgGADgEAEQgLAGACgC");
	this.shape_34.setTransform(168.5156,63.275);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgTA/IgBlAQgCgIAVAAQAUgBgEASIACALQgCAgACA4QACBMAAARQAAAagCArQgCAsAAAaQAAAmAEBLQAAAHACAXQACAWgFAHQgFAGgHADQgHAEgGgDQgPgGACgS");
	this.shape_35.setTransform(163.5305,122.0224);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAAgtQAAAVABBG");
	this.shape_36.setTransform(161.325,142.125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AABgiQAAAzgBAS");
	this.shape_37.setTransform(161.3,134.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AADiaQAAATgBAaQgCAuAAACQgBBCABAZQAAAUgBAqIgBA/");
	this.shape_38.setTransform(165.3333,81.65);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAAiJIAAAoQgBA2ABBCQAAAiABBS");
	this.shape_39.setTransform(161.9167,81.85);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AABi6IgBF1");
	this.shape_40.setTransform(162.075,49.325);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAACzQAAlLAAga");
	this.shape_41.setTransform(165.6,48.275);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhQgVQAFAEAYAUQAYATARAAQANABArgKQAcgFAGgG");
	this.shape_42.setTransform(163.8,150.9263);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgdgSQAIAFAdAJQAZAJgEAP");
	this.shape_43.setTransform(168.9593,149.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhFgTQADABAWASQAZARANACQAKACAegFQAfgFAFgH");
	this.shape_44.setTransform(163.975,149.0286);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgYAIQgBgEABgHQAagEAYAA");
	this.shape_45.setTransform(158.425,147.525);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Al5AmQBQAABwgLQBAgHB+gOIB2gKQBAgFBZgQQAUgDAqgEQAjgEAFgB");
	this.shape_46.setTransform(117.75,151.825);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgBgpQAAAdADA2");
	this.shape_47.setTransform(130.575,146.775);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAAgtQgBAHACBU");
	this.shape_48.setTransform(129.91,135.75);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgIAaQAAgXABgJQAEgXAKAFQABAsABAF");
	this.shape_49.setTransform(128.85,125.9478);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAAAtIAAhZ");
	this.shape_50.setTransform(128.15,135.975);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AABAtQAAgRgBgmIAAgi");
	this.shape_51.setTransform(128.2583,147);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAVA+QgDAUADAdQAEAnAAAKQgaALgMAEQgGiggDg9QAAgOAAgjQABgigBgPQgBgJAAgFQgBgLACgCQACgEAPACQAHABALABQADALAAAdQAAAfABAH");
	this.shape_52.setTransform(77.5333,139.6275);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AmXAcQAdgEAvgBQBHgBAFgBQA4gCBYgHQA7gDA/gGQA3gEAkgBQAbgBA8gHQBAgHAYgBQAugDBVgG");
	this.shape_53.setTransform(120.4,142.625);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AmMAjQgDAAgEAAQgIABgEACQgBgDAAgGQAAgHABgCQARgGAogCQAWAAAqgBQBdgFBugGQDNgOC4gRQAQgBApgCQAmgBAYgC");
	this.shape_54.setTransform(119.325,141.975);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgBg0QAAARABAkQACAhAAAT");
	this.shape_55.setTransform(79.48,138);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AmjAKQA6AABfgEQB0gGAlAAQCLgEDkAAQAgAAA/gCQATAAAbgBQAbgBgDgB");
	this.shape_56.setTransform(119.6106,129.375);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AmjgIQAAAGABAKQAUACAngCQAWgCArgDQBsgFBsAAQA0AABigCQBYgCA/AAQAiAABBADQA6ABAogG");
	this.shape_57.setTransform(119.4167,131.4375);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgEgLQgJAIAHAJQAHAKAGgIQAGgIgGgGQgFgIgFAM");
	this.shape_58.setTransform(56.3295,93.5028);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgJgBQgBAMAJADQAJACACgOQABgKgHgEQgGgDgGAI");
	this.shape_59.setTransform(56.0577,88.1429);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgJgGQgDAOALAEQALAEABgOQABgHgKgFQgJgFgCAJg");
	this.shape_60.setTransform(55.8314,82.4064);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgKgBQACAIAIAFQAKAEABgLQABgKgJgFQgIgGgDAK");
	this.shape_61.setTransform(55.905,77.6124);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgDAHQAJAGAEgMQgEgFgGgDQgDgCgDACQgCACgBADQgBAFAHAEg");
	this.shape_62.setTransform(48.3057,76.636);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgDgKQAAAAgBAAQgMABAIALQAIAOAHgHQAJgIgHgGQgEgFgIAAg");
	this.shape_63.setTransform(48.537,81.5695);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgDgNQgOAFALANQAJAPAHgKQAFgIgHgHQgFgFgGgDg");
	this.shape_64.setTransform(48.9495,87.3541);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgJgIQgIANAOAHQANAIADgOQACgJgJgHQgIgGgEAD");
	this.shape_65.setTransform(49.3826,93.2616);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhcBxQACAJAngCQAUgBAhgCQANABAsAGQAnAFADgIIgBgLQgChlgDgxQAAgXAAgNQgCgZgIgIQgFgFgOgCQgQgCgGgCQgUgEg3gBQg9gBgDAHQgCAEgCAkQgCAkABAOQAGA1ABAPQACAkAAAhg");
	this.shape_66.setTransform(52.1583,85.6277);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgbAcQAugtAJgK");
	this.shape_67.setTransform(70.325,157.975);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ACLqmQAACeADDHQAEEEAGBhQADAqABBNQABBSACAlQABAQABBOQABA6AFAjQADAVACBMQANAAAOACQgBAKgOATQgHAKgOAQQgcAogPALQgSAPhmgCQhpgFgNABQgbAEgNAAQgYAAgQgFIASgNIAQgRQARgQAMgS");
	this.shape_68.setTransform(56.075,99.7121);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ABZqXQgGARACC0QABCZADAtQABAdACA3QAIBtAGB4QAGCRAABzQAAA/AGCLQACAnAHBxQAAAHh8gDQh+gDgDAD");
	this.shape_69.setTransform(54.8001,94.8807);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgMqVQgJAaAIFcQABAOgCAnQgCAmAAAPQABALADBVQACA7ABAoQADEtATDqQAFA1AAA8");
	this.shape_70.setTransform(40.3311,94.975);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgGgHQgFAFACAHQACAHAHAAQAMABgBgOQgBgPgOAIg");
	this.shape_71.setTransform(19.127,81.8367);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgGgHQgFAFACAHQACAHAHAAQAMABgBgOQgBgPgOAHg");
	this.shape_72.setTransform(25.877,77.0258);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgGgHQgFAFACAHQACAHAHAAQAMABgBgOQgBgPgOAIg");
	this.shape_73.setTransform(25.727,88.6389);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgKgHQADAMAHADQAEACAFgFQAEgEgEgEQgFgFgOABg");
	this.shape_74.setTransform(25.75,71.1894);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgHgBQAGANAEgBQAEgBABgIQABgIgEgDQgEgDgIALg");
	this.shape_75.setTransform(18.735,86.195);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgHgBQAGANAEgBQAEgBABgJQABgHgEgDQgFgDgHALg");
	this.shape_76.setTransform(25.56,82.295);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgHgBQAGANAEgBQAEgBABgJQABgHgEgDQgEgDgIALg");
	this.shape_77.setTransform(18.535,76.895);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgMAAQAFAGAHADQAKAEADgKQACgIgLgDQgJgDgFAH");
	this.shape_78.setTransform(18.791,70.2371);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AB+hiIARAXQgTAXgVAQQgIAGgnAZQg0AjgvAcQhXAzgMgL");
	this.shape_79.setTransform(20.225,174.9976);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiBBPQAOgDAkgVQAmgXALgGQAQgIBFgsQAzgkAYgQ");
	this.shape_80.setTransform(19.85,173);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgIlcQgBAXADA3QABAZAAAxQACAsAABbQAAA/ADBgQAFB5ABAnQAAALACAnQACAegBAL");
	this.shape_81.setTransform(31.3942,130.2);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ahrg4QARAXBaAlQBeAnAOAO");
	this.shape_82.setTransform(18.575,63.875);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ABtmYQgDHTAAARIABAoQABATAEAbQAEAbgDAzQgDA1ADAZQABAOAEAfQADAcgBASQgEgIgKgFQgBAAgSgGQgegLgkgTQgDgChFgbQg8gYgIgJ");
	this.shape_83.setTransform(18.55,54.725);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(3.7,8.9,241,177.1), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ap+M+IAA57IT9AAIAAZ7g");
	mask.setTransform(63.85,83.025);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AjUBWQA3hVCGgyQCCgyBqAU");
	this.shape.setTransform(70.625,74.6264);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAwBzQAFgOAFgHQAFgHALgJQACgBAMgHQAJgFACgFQADgIgDgYQgDgWAIgKQAHgJAPgNQASgPAFgGQALgLAAgJQgBgHgKgNIgFgHQgPgUgeAAQgSAAgjAJQgtAKgUATQgGAGgGAKQgHANgCADQgIALgUANQgXAOgIAHQgbAdgIAKQgUAZgFAT");
	this.shape_1.setTransform(81.3511,11.925);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgbCJQAIgRAEgXQAGglABgDQADgOAIgRQAFgKAKgTQAOgbgHgqQgDgPgHgWQgJgbgEAA");
	this.shape_2.setTransform(83.4558,28.425);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AmwgBQgOgqA4hCQAdghA9gzQAbgXA2gRQApgNAygIQAcgFAsAEQAoADAfAIQAgAIAWAbQANARATApQAUAsASAVQAHAIAaAmQAXAiAMAJQAEAEBtB9QBqB4AKAF");
	this.shape_3.setTransform(83.6269,67.4559);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAahSQgRARgJARQgFAMgKAdQgCAHgFAOQgDALAAALQABAHADAQQACAQgCAI");
	this.shape_4.setTransform(59.4219,34.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ah2DBQgIg3AFgeQAFgXAagsQAKgSAfgcQAegcAJgRQANgZAJgLQALgQAVgPQAEgDAYgnQASgdAigE");
	this.shape_5.setTransform(73.625,24.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAGBNQgfgMgXgZQgZgagFgeQgGgmAjgQQAhgPAcAXQAFAEAJAKQAIAKAFAFQALAJAeAN");
	this.shape_6.setTransform(23.9561,35.888);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AIlKUQgrgwg8hHQh2iMhhiJQgUgdgsg5Qgvg8gSgZQgQgXguhJQgshKgPgUQg+hWgshTQghg8gBAAQgYgCgQgMQgRgLgOgWQgcgqgSgSQgcgcglgJQgogKgRgHQgfgMgSgVIgRgZQgJgOgMgGQgYgJgKgFQgQgJgJgSQgIgQAIgLQAGgJATgIQAigOAmAIQAkAIAcAY");
	this.shape_7.setTransform(55.3875,99.6262);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhIApQArgiA5gSQANgEAQgMQALgIAFgG");
	this.shape_8.setTransform(64.125,16.2);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,127.7,166.1), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhTBdIAGgnIAYADQAKAAAGgEQAHgEgCgJIgeiGIA6AAIAKBLIAkhLIAqAAIhOCUQgLAWgLAIQgQALgZAAQgNAAgNgCg");
	this.shape_9.setTransform(86.0125,60.2669,0.84,0.84);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AANBGQgEgDgDgPQgCgWgCgGQgDgJgLAAIgFAAIgJA3Ig3AAIAYiMIA2AAIgJAzIAEAAQAJABAKgTQAGgQAFgFQAEgHAGgFIAyAAQgKALgCAFQgLAXgGAJQgIANgOACQAQAFAHAQQADAJACAUQADASAFAJg");
	this.shape_10.setTransform(72.9933,58.188,0.84,0.84);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AguBGIARhnIgoAAIAHglICEAAIgHAlIgnAAIgQBng");
	this.shape_11.setTransform(60.94,58.188,0.84,0.84);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag8A+QgLgLAAgSQAAgRAKgLQAHgIASgHQATgIAjgBIABgKQAAgKgNAAQgKAAgFAHQgDADgCAHIgpgLQAHgRAQgLQATgMAcAAQAYABAOAIQATALAAAZQAAAIgDANIgDARIgFAiQgBAOACAMIg0AAQgCgKACgMQgOAZgcAAQgSAAgKgLgAgLANQgIAGAAAIQAAAGAEADQAEADAFABQASgBACghQgOgBgLAIg");
	this.shape_12.setTransform(47.7318,58.188,0.84,0.84);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AANBGQgFgDgBgPIgGgcQgCgJgKAAIgHAAIgJA3Ig2AAIAXiMIA3AAIgIAzIADAAQAJABAJgTIALgVQAGgIAFgEIAyAAQgIAJgEAHQgLAXgGAJQgJANgNACQARAFAFAQQADAFAEAYQACASAFAJg");
	this.shape_13.setTransform(35.0275,58.188,0.84,0.84);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Ag8A+QgLgMAAgRQAAgQAKgMQAHgIASgHQATgIAjgBIACgKQAAgKgOAAQgJAAgGAHIgFAKIgpgLQAGgRARgLQATgMAcAAQAYABAOAIQATALAAAZIgDAVIgCARQgIApACATIgzAAQgBgKABgMQgOAZgcAAQgSAAgKgLgAgLANQgHAGgBAIQAAAGAFADQACADAGABQASgBACghQgOgBgLAIg");
	this.shape_14.setTransform(15.6246,58.188,0.84,0.84);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAEBGIAJg2IgeAAIgJA2Ig2AAIAXiMIA2AAIgIAyIAeAAIAIgyIA2AAIgXCMg");
	this.shape_15.setTransform(2.3744,58.188,0.84,0.84);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhTBeIAGgoQALADANAAQALAAAFgEQAIgEgDgJIgeiGIA5AAIALBLIAkhLIAqAAIhOCUQgLAVgLAJQgPAMgaAAQgNAAgNgCg");
	this.shape_16.setTransform(85.5763,37.1053,0.84,0.84);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhJBHIAYiNIBMAAQAZAAALAKQALAIAAAPQAAAMgHAIQgHAKgNADQAMAEAGAHQAGAIAAAMQAAAQgKALQgIAKgOADQgNAEgUAAgAgPArIAOAAQAIAAAFgDQAFgFAAgIQAAgGgEgEQgEgEgJAAIgLAAgAgGgNIAKAAQALAAAEgGQAEgEAAgHQAAgGgEgDQgDgDgHAAIgKAAg");
	this.shape_17.setTransform(72.1161,35.0264,0.84,0.84);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AhRBeIAfi5IAyAAIgEAYIABAAQADgMAIgFQALgJAQAAQATAAAMAMQAQAPAAAdQAAAlgSAbQgRAZgfAAQgWAAgKgSIAAAAIgKA8gAACg2QgDAEgDAKIgDAPQgEAVAAAFQAAAIAEAEQAEAGAFAAQANAAAGgRQAHgSAAgWQAAgLgEgFQgEgFgIAAQgGAAgEAFg");
	this.shape_18.setTransform(58.2569,36.7903,0.84,0.84);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag8AzQgPgSAAgaQAAgnAfgXQAVgRAeAAQAdAAASAPQAWATgBAjIAAAOIhgAAIAAAGQAAAMAGAGQAGAFAIAAQALAAAGgJQAFgFABgGIAvAIQgIATgSAMQgVAOgbAAQgkAAgTgWgAgHghQgIAGgBALIAnAAIABgFQAAgIgEgFQgFgFgJAAQgIAAgFAGg");
	this.shape_19.setTransform(44.7547,35.0264,0.84,0.84);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhRBeIAfi5IAyAAIgEAYIABAAQADgLAHgGQAMgJARAAQASAAAMAMQAQAQAAAcQAAAYgIAUQgEANgGAHQgRAZgfAAQgVAAgKgSIgBAAIgKA8gAACg2QgFAGgEAXQgEAVAAAFQAAAIAEAEQAEAGAFAAQAMAAAHgRQAHgSAAgWQAAgLgEgFQgDgFgJAAQgGAAgEAFg");
	this.shape_20.setTransform(30.3916,36.7903,0.84,0.84);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag8AzQgPgTAAgZQAAgmAfgYQAWgRAdAAQAdAAASAPQAWATAAAjIgCAOIhfAAIAAAGQAAAMAGAGQAFAFAJAAQALAAAHgJIAFgLIAvAIQgHARgSAOQgWAOgcAAQgjAAgTgWgAgIghQgGAGgCALIAoAAIAAgFQAAgIgEgFQgFgFgJAAQgHAAgHAGg");
	this.shape_21.setTransform(16.8894,35.0264,0.84,0.84);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAEBHIARhoIgeAAIgRBoIg2AAIAXiNICKAAIgXCNg");
	this.shape_22.setTransform(2.9042,35.0264,0.84,0.84);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAEBHIALhDIgnA4IgCALIg3AAIAYiNIA2AAIgLBDIAng5IABgKIA3AAIgXCNg");
	this.shape_23.setTransform(71.8544,12.3764,0.84,0.84);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Ag7BRQgTgRAAgkQAAgmAPggQAOgZAVgKQAOgHAQgCIAhgDIAsgIIgGAlQgHAEgLACQgRAEgUABQgYACgIACQgYAIgEAZIABAAQAHgKANgGQANgFANgBQAfABAOAQQAOAPAAAYQAAAdgPATQgVAcgnAAQgfAAgRgRgAgQADQgKANAAAdQAAAIAEAFQADAGAHAAQANAAAGgPQAGgMAAgUQAAgLgEgFQgEgEgGgBQgJAAgGAHg");
	this.shape_24.setTransform(58.7721,10.3395,0.84,0.84);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Ag0A5QgVgRABgiQAAghATgVQAXgYAhAAQAdAAASAOQAXASAAAiQAAAWgMAVQgLASgTAKQgSAIgTAAQgcAAgSgQgAgLgYQgIAQAAAaQABALADAFQAEAGAIAAQAKAAAFgMQADgHACgQIACgYQAAgLgEgFQgFgEgEAAQgLAAgGAPg");
	this.shape_25.setTransform(44.8499,12.3764,0.84,0.84);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhRBeIAfi5IAyAAIgDAYIAAAAQADgLAIgGQALgJAQAAQATAAAMAMQAQAPAAAdQAAAlgSAbQgRAZgfAAQgWAAgKgSIAAAAIgKA8gAACg2QgEAFgFAYQgEAVAAAFQAAAIAEAEQAEAGAFAAQANAAAGgRQAHgSAAgWQAAgLgEgFQgEgFgIAAQgGAAgEAFg");
	this.shape_26.setTransform(30.6338,14.1403,0.84,0.84);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhHBLQgLgOAAgUIAvgGQACAHAFAGQAGAHAOAAQANAAAGgFQAIgGAAgJQAAgJgGgEQgGgDgNAAIgTAAIAGgoIAVAAQAOAAAGgFQAHgFAAgJQAAgGgFgFQgFgEgKAAQgLAAgIAGQgIAHgDAKIgvgHQAGgdAZgPQAVgNAhAAQAcAAARAJQAVAOAAAYQAAARgMAPQgLALgQADQAOADAIAIQAKAJAAARQAAAPgIAOQgIAOgOAJQgUALglAAQgqAAgSgWg");
	this.shape_27.setTransform(16.9426,10.3605,0.84,0.84);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(-4.4,2.2,97.5,66.1), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag8A+QgLgMAAgRQAAgQAKgMQAJgKAQgFQATgIAjgBIACgKQAAgLgOAAQgJAAgFAIIgGAJIgpgKQAGgRARgLQAUgLAbAAQAYgBAOAJQATAKAAAaIgDAVIgCARQgIApACAUIgzAAQgCgLACgMQgOAagcgBQgRAAgLgLgAgLAMQgHAHgBAJQABAFAEAEQACACAGAAQASAAACgiQgOAAgLAHg");
	this.shape_28.setTransform(71.7987,46.9143,0.7,0.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AANBHQgFgFgCgOQgDgYgBgEQgDgKgKAAIgGAAIgJA5Ig3AAIAXiNIA3AAIgIA0IAEAAQAJgBAIgSIALgWQAFgHAGgEIAyAAQgIAKgEAGQgLAYgFAHQgKAOgOADQASAEAGAPQADAIADAWQACASAFAKg");
	this.shape_29.setTransform(61.2115,46.9143,0.7,0.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AguBHIARhoIgoAAIAGglICFAAIgGAlIgoAAIgRBog");
	this.shape_30.setTransform(51.1668,46.9143,0.7,0.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("Ag8A+QgLgMAAgRQAAgQAKgMQAJgKAQgFQATgIAjgBIACgKQAAgLgOAAQgIAAgHAIIgFAJIgpgKQAGgRARgLQATgLAcAAQAYgBAOAJQATAKAAAaQAAAIgDANIgDARQgGAqACATIg0AAQgBgNABgKQgOAagcgBQgSAAgKgLgAgKAMQgIAGAAAKQAAAFADAEQAEACAFAAQATAAACgiQgPAAgKAHg");
	this.shape_31.setTransform(40.1421,46.9143,0.7,0.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AANBHQgEgEgDgPQgDgYgBgEQgDgKgLAAIgFAAIgJA5Ig3AAIAXiNIA3AAIgJA0IAEAAQAKgBAIgSQAHgPAEgHQAFgGAGgFIAyAAQgKALgCAFIgJARIgIAOQgIAOgPADQARAEAHAPQADAKACAUQADASAFAKg");
	this.shape_32.setTransform(29.5724,46.9143,0.7,0.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Ag8AyQgPgSABgZQgBgnAegXQAWgSAeABQAdAAASAPQAVASABAkIgBANIhgAAIAAAHQAAALAGAHQAFAEAJAAQAKABAHgJQAFgFABgGIAvAIQgKAVgQAJQgVAPgcAAQgiAAgUgXgAgIghQgGAGgDALIAoAAIABgFQAAgJgEgEQgFgFgJgBQgIAAgGAHg");
	this.shape_33.setTransform(92.5911,66.2143,0.7,0.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("Ag7BRQgTgTAAgiQAAgqAQgbQAMgaAXgKQANgGARgDIAhgEQAVgCAWgFIgGAlQgGAEgMACQgSAEgTABQgYABgHADQgYAHgFAaIABAAQAQgWAfAAQAcAAAQAQQAPAQAAAYQAAAbgQAVQgVAcgnAAQgeAAgSgRgAgPADQgLANAAAdQAAAJAEAEQAEAGAGAAQANAAAGgPQAGgNAAgTQAAgMgEgFQgEgDgFAAQgJAAgGAGg");
	this.shape_34.setTransform(81.7939,64.5168,0.7,0.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("Ag8AyQgPgSAAgZQAAgnAfgXQAWgSAdABQAdAAASAPQAWASAAAkQAAAHgCAGIheAAIgBAHQAAALAGAHQAFAEAJAAQAKABAIgJQAEgFABgGIAwAIQgKAVgQAJQgWAPgcAAQgiAAgUgXgAgIghQgGAGgCALIAoAAIAAgFQAAgJgEgEQgFgFgJgBQgHAAgHAHg");
	this.shape_35.setTransform(69.9992,66.2143,0.7,0.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgwA6QgVgSAAggQAAgbAPgVQAIgNAOgIQASgLAVAAQAZAAAQALQAVAQABAbIguAGQAAgIgCgHQgEgMgKAAQgOABgDASQgGAVAAASQAAAJAEAGQAEAFAHAAQALAAAFgKQAEgHABgHIArAKQgGAQgLANQgUATgeAAQgaAAgTgPg");
	this.shape_36.setTransform(59.2895,66.2143,0.7,0.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ag8A+QgLgMAAgRQAAgQAKgMQAJgKAQgFQATgIAjgBIABgKQAAgLgNAAQgJAAgGAIIgFAJIgpgKQAHgRAQgLQATgLAcAAQAXgBAPAJQATALAAAZQAAAIgDANIgDARIgFAjQgBAOACAMIg0AAQgCgLACgMQgOAagcgBQgSAAgKgLgAgKAMQgIAGAAAKQAAAFADAEQAEACAFAAQATAAACgiQgPAAgKAHg");
	this.shape_37.setTransform(43.6449,66.2143,0.7,0.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAeBHIARhkIgBAAIgtBkIgfAAIgOhkIgBAAIgQBkIgpAAIAYiNIBDAAIAJBIIAAAAIAhhIIBIAAIgYCNg");
	this.shape_38.setTransform(31.1152,66.2143,0.7,0.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Ag8A+QgLgMAAgRQAAgQAKgMQAJgKAQgFQATgIAjgBIACgKQAAgLgOAAQgIAAgHAIIgFAJIgpgKQAHgRAQgLQATgLAcAAQAYgBAOAJQATAKAAAaQAAAIgDANIgDARQgGAqACATIg0AAQgBgNABgKQgOAagcgBQgSAAgKgLgAgKAMQgIAGAAAKQAAAFADAEQAEACAFAAQATAAACgiQgPAAgKAHg");
	this.shape_39.setTransform(17.9906,66.2143,0.7,0.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgvA6QgXgRAAghQABgaAPgWQAWghAnABQAZAAAQALQAVAQACAbIgvAGQAAgIgCgHQgEgMgKAAQgNABgEASQgGAUAAATQAAAJAEAGQAEAFAHAAQALAAAGgKIAEgOIArAKQgHASgLALQgTATgeAAQgaAAgSgPg");
	this.shape_40.setTransform(7.8933,66.2143,0.7,0.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("Ag0A6QgXgRABgjQgBghAVgVQAWgYAmAAQAgAAAUAOQANALAFAVIgxAGQAAgIgEgFQgGgGgJAAQgJAAgHAHQgFAGgDAMIAlAAIgFAaIgkAAIAAAHIABAMQAEAJALAAQAJAAAIgHQAEgEAEgIIAuAGQgJAXgWANQgUAKgYAAQgaAAgSgPg");
	this.shape_41.setTransform(99.8867,85.5163,0.7,0.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("Ag8A+QgLgMAAgRQAAgRAKgLQAJgKAQgFQAVgIAhgCIABgJQAAgKgNAAQgJAAgGAHIgFAJIgpgJQAGgSARgLQASgLAdAAQAYAAAOAIQATAMAAAYQAAAHgDAOIgDARIgFAiQgBAOACANIg0AAQgCgMACgLQgNAZgdAAQgSAAgKgLgAgKANQgIAEAAALQAAAFADADQAEAEAFAAQATAAABgjQgPAAgJAIg");
	this.shape_42.setTransform(88.3895,85.5163,0.7,0.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AguBHIAQhoIgnAAIAHglICEAAIgGAlIgoAAIgRBog");
	this.shape_43.setTransform(79.1322,85.5163,0.7,0.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("Ag9A+QgKgMAAgRQAAgQAKgMQAIgJARgGQAVgIAhgCIABgJQABgKgOAAQgIAAgHAHIgGAJIgogJQAGgSARgLQASgLAcAAQAaAAANAIQATALAAAZIgCAVIgEARQgGApACAUIg0AAQgCgNACgKQgOAZgcAAQgSAAgLgLgAgKANQgIAEAAALQAAAFADADQAEAEAFAAQASAAACgjQgPAAgJAIg");
	this.shape_44.setTransform(68.1075,85.5163,0.7,0.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AANBHQgEgEgDgPQgDgYgBgEQgDgJgKAAIgGAAIgJA4Ig3AAIAXiNIA3AAIgIAzIADAAQAKAAAIgSIALgWQADgFAIgGIAyAAQgIAJgEAHQgLAXgGAIQgIAOgPADQARADAHAQQADAIADAVQACATAFAKg");
	this.shape_45.setTransform(57.5203,85.5163,0.7,0.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAWBZIAGglIg4AAIgFAlIgyAAIAMhKIANAAQAQgVAJgyIAFggIBwAAIgRBnIAQAAIgMBKgAgCgKQgFARgFAIIAaAAIALhCIgTAAg");
	this.shape_46.setTransform(45.2181,86.7937,0.7,0.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgqBiIAXiNIA2AAIgYCNgAgRg7IAHgmIA1AAIgGAmg");
	this.shape_47.setTransform(37.7633,83.6263,0.7,0.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AhJBHIAXiNIBNAAQAYAAAMAJQALAKAAAOQAAAMgHAIQgHAKgNADQALADAHAIQAGAIAAAMQAAAQgKALQgJAKgOADQgMAEgVAAgAgPArIAOAAQAJAAADgDQAGgEAAgJQAAgHgEgDQgEgEgJAAIgLAAgAgGgNIAKAAQAKAAAFgGQAEgFAAgGQAAgGgEgDQgFgDgFAAIgKAAg");
	this.shape_48.setTransform(28.7511,85.5163,0.7,0.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("Ag8AyQgOgRAAgaQgBgRAIgQQAIgSAPgLQAWgRAdAAQAcAAATAPQAVASAAAkIgBAOIheAAIgBAGQAAAMAGAGQAGAFAIAAQALAAAHgJQACgDADgIIAwAIQgIARgSAOQgVAOgdAAQgjAAgTgXgAgIghQgHAGgCALIApAAIAAgFQAAgJgEgEQgFgFgIAAQgHAAgIAGg");
	this.shape_49.setTransform(13.054,85.5163,0.7,0.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AADBHIAJg4IgdAAIgJA4Ig2AAIAXiNIA3AAIgIAxIAcAAIAJgxIA2AAIgXCNg");
	this.shape_50.setTransform(1.3993,85.5163,0.7,0.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AghAxIAegwIgWAAIAIgyIAzAAIgHAvIgmAzg");
	this.shape_51.setTransform(106.2791,32.4947,0.7,0.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAEBHIALhDIgnA4IgCALIg2AAIAXiNIA2AAIgIAzIgDAQIAKgPIAdgqIACgKIA2AAIgXCNg");
	this.shape_52.setTransform(98.3693,27.6123,0.7,0.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AguBHIARhoIgoAAIAGglICFAAIgGAlIgoAAIgRBog");
	this.shape_53.setTransform(88.3595,27.6123,0.7,0.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AhTBdIAGgnQAPADAJgBQAMABAFgEQAGgEgCgJIgfiHIA7AAIAKBMIAlhMIApAAIhOCVQgKAWgMAIQgPAMgaAAQgNgBgNgCg");
	this.shape_54.setTransform(78.1748,29.3447,0.7,0.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AhRBeIAfi5IAyAAIgDAYIAAAAQADgLAHgGQAMgJAQAAQASAAANAMQAQAQAAAcQAAAYgIAUQgFANgFAHQgRAZgfAAQgWAAgJgSIgBAAIgLA8gAACg2QgFAGgEAXQgDARgBAJQAAAIADAEQAFAGAFAAQAMAAAHgRQAHgUgBgUQAAgLgDgFQgEgFgHAAQgHAAgEAFg");
	this.shape_55.setTransform(66.5726,29.0822,0.7,0.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AANBHQgFgEgBgPIgGgcQgBgJgLAAIgHAAIgJA4Ig2AAIAXiNIA3AAIgIAzIADAAQAJAAAJgSIALgWQAEgFAHgGIAyAAQgIAJgEAHIgRAfQgJAOgNADQAQADAGARQADAFAEAXQACATAFAKg");
	this.shape_56.setTransform(55.7229,27.6123,0.7,0.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("Ag8AyQgPgRAAgaQAAgRAIgQQAIgRAPgMQAWgRAdAAQAcAAATAPQAWASgBAkIgBAOIhfAAIAAAGQAAALAGAHQAFAFAJAAQALAAAHgJQACgDADgIIAwAIQgIARgSAOQgVAOgdAAQgiAAgUgXgAgHghQgIAHgBAKIAnAAIACgFQAAgIgFgFQgFgFgIAAQgIAAgGAGg");
	this.shape_57.setTransform(39.4483,27.6123,0.7,0.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AADBHIAJg4IgcAAIgKA4Ig2AAIAXiNIA2AAIgHAyIAdAAIAIgyIA3AAIgYCNg");
	this.shape_58.setTransform(27.7936,27.6123,0.7,0.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AANBHQgFgEgCgPQgDgZgBgDQgDgJgLAAIgFAAIgJA4Ig3AAIAXiNIA3AAIgJAzIAFAAQAJAAAIgSIALgWQADgFAIgGIAyAAQgIAJgEAHIgQAfQgJAOgPADQARADAHARQACAGADAWQADATAEAKg");
	this.shape_59.setTransform(11.974,27.6123,0.7,0.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AALBfIANhIIgOAAIgrBIIhCAAIA4hQQgKgFgHgIQgKgMAAgUQAAgdAUgRQAMgMATgDQALgDATAAIBZAAIgeC9gAgHgvQgGAGAAAIQAAAIAFAEQAGADAHAAIAZAAIAFgiIgaAAQgJAAgHAFg");
	this.shape_60.setTransform(-0.7307,25.9323,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(-7.7,19.3,116.4,73.7), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("ApmM3IAA5tITNAAIAAZtg");
	mask_1.setTransform(61.475,82.25);

	// Layer_3
	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AGrKPQgSgkgxglQg5gmgYgUQgzgogsg+QgagkhOhPQhFhGgcgyQg6hlgCgDQgkg5gpgiQgXgUg9hkIg4hhQACgigbgjQgKgOgtgsQgkgjgKgYQgOghAUgiQAlg9BUg1QBTgzBFgIQBAgIBWATQBsAXAXATQAJAHAHARQAFAJAHASQAPAkAXAfQASAaA1BAQAKANAVAaQASAXAMAQQAMARAXAnQAcAwgCAH");
	this.shape_61.setTransform(79.8246,98.5939);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AGsB0QgCgGgMgQQgMgOgCgHQgBgEgCg3QgDg1gEgPQgHgWgcgKQghgMgJgKQgDgDgRgeQgLgTgTgJQgIgDgggGQgXgEgLgNQgegjguAAQgEAAgeAFQgSADgPgHQghgOgmAOQgjANgYAfQgQAWAAALQABAEADAHQAFAHAAADQAEASgIAQQgLASgHAMIgIAGQgUAJgbgNQgQgIgZgUQgFgEgNgHQgNgHgFgEQgPgQgOgNQgbgagNgGQgWgJgZAEQgbAEgPAPQgiAiAOAWIAGAHQAYAPAcAdQAtAuABABQAHAHAZANQAXANAIAJQAGAHAWAiQAWAhAJAKQANAOAQALQAHAGAaAPQAPAKAqAWQAmAWAMAT");
	this.shape_62.setTransform(43.2832,24.1875);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AjWATQA6g6BKgLQA7gJBOAVQAaAHAjATQAiAQAWARQAJAHALAMQALAKAMAE");
	this.shape_63.setTransform(61.8,26.09);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ai6BIQAPguBog3QBdgzChAK");
	this.shape_64.setTransform(66.025,61.5504);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgfAVQANAPAWgWQAUgSAIgW");
	this.shape_65.setTransform(15.3,21.7791);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AjhAAQAOgEA5gZQAsgTAcgFQBAgNBGARQBAAPA4AmQAOAJARAXQARAVAGAD");
	this.shape_66.setTransform(60.575,29.0433);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhVhpQAIAKAIAUQAJAYAFAIQAHANAPAKQAHAGAVAMQAeASAYAbQAaAeALAg");
	this.shape_67.setTransform(38.575,29.25);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgkgFQAPAjAegHQAggIgFgm");
	this.shape_68.setTransform(69.2588,12.9647);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgdAMQALASASABQARABAHgNQAGgKAAgPQgBgPgFgK");
	this.shape_69.setTransform(58.975,6.7036);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgqgjQgMArAbASQAWAQAdgKQAPgGAFgLQAFgMgHgM");
	this.shape_70.setTransform(45.659,5.008);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AijguQAIAaAOAJQAHAEAaAFQAjAEASACQAeACA5AJQBTAOAxAS");
	this.shape_71.setTransform(52.875,14.025);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ajih8QAAAfACALQAEAaAQAJQAHAFAYAAQALACAWAFQAVAFAMACQC2AbBtBaQAGAEARARQAPAOAFAB");
	this.shape_72.setTransform(60.25,15.725);

	var maskedShapeInstanceList = [this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,123,164.5), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AnnNlIAA7JIPPAAIAAbJg");
	mask_2.setTransform(48.775,86.925);

	// Layer_3
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ah9AcQBigsCZgL");
	this.shape_73.setTransform(74.425,80.725);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AjZBOQAUg1BcglQA8gYBTgQQAggGA6gLQAwgIAqAA");
	this.shape_74.setTransform(63.275,81.725);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AFQI7QADADAPgOQAPgOgEgBQhGghgqgfQgugigsg2QgWgaghgtQgpg2gOgRQgQgUgwgzQgqgsgVgfQgVgggkhAQgmhCgUgeQgPgYgggmQgkgqgNgTQgjgpgPgSQgZgggFgjIAEgVQgBgQAWgoQAYgqAGgLQAQgbAigYQAegWAigMQAxgTA/gBQAvAABCAJQAOACAnAFQAlAFAQAEQAcAIAMALQAPAPARAcQAbAtABABQBKBtAKgF");
	this.shape_75.setTransform(60.4831,116.251);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#FFFFFF").ss(1.2,1,1).p("AjEgzQAIATAlAMQANAEAsAJQAlAHBIAHQAYADAeAJQAMAEAoAOQA/AWANgL");
	this.shape_76.setTransform(45.575,39.4583);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#FFFFFF").ss(1.2,1,1).p("ABxgoQgOAGgdgOQgigRgKAAQgXgBgLAAQgVgBgOgDIg+gRQgpgJgRAGQgYAJgDAoQgCAmARAQQAOAOAoALQAgAJBMAEQBFADAnAOQBfAjABgO");
	this.shape_77.setTransform(44.9594,31.3111);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgHgSQACAFAJANQAIANgHAG");
	this.shape_78.setTransform(51.8759,31.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgNgVIASATQAKAMgBAN");
	this.shape_79.setTransform(45.9795,29.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgPgWQANACAKAQQALAPgFAM");
	this.shape_80.setTransform(38.3653,27.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiDifQABACAIANQAFAIAFAFQAPAQAEAFQAGAJAMAcQAKAYAKAMQAvA1AOAOQAJAIAWAQQAUAOAKAJQAUATASAWQAFAFAHAKQAKAKAFAR");
	this.shape_81.setTransform(14.65,55.75);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhbBDQgPghAFgdQAFgdAXgVQAPgNADgDQALgGALACQAEABAEAKQADAGADAKQAEAJAiAdQAbAXABAAQAZARAfAB");
	this.shape_82.setTransform(10.7609,33.0403);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgvDbQgFgRgDgjQgDgdABgGQAEgSAIgUQAGgLABgEQADgGgCgJQgCgRAAgUQAAgXgCgFQgCgHgRgXQgGgKgFgVQgGgbAAgeQAAgKgSgiQgRggACgEQAEgIAUgGQARgGAMABQAUACAZAUQAZAUAFASQAGARAGAoQACAIAKAJQAGAFAKAKQAaAdAPAaQAGAJAGAS");
	this.shape_83.setTransform(27.1645,22.3673);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AixgjQANgDAZgHQAWgGAQgCQArgFAbAEQAOACASAGQAKAEAVAGQAmAMAQAJQALAHAVAMQATAMAMAKQACADAMAOQALAOAEAA");
	this.shape_84.setTransform(47.675,48.9434);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhljBQAHAMAdAQQAeAQAPAaQAGAJAFAXQAFAWAFAJQADAEAGAFQAHAGADADQAQAQAMARQAJAMAAAQQAAAmgFAmQgCATAFAPQAFAPANAPQAXAbAGAI");
	this.shape_85.setTransform(59.775,41.175);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhIg6QAQgBAVAEQAXAEAMAHQAKAGAJAOQAFAIAKAQIAUAhQACAEAIAKQAHAIACAF");
	this.shape_86.setTransform(45.125,20.1472);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ag9g3QAoABAlAmQAVATAJANQAOAUACAU");
	this.shape_87.setTransform(36.85,16.65);

	var maskedShapeInstanceList = [this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85,this.shape_86,this.shape_87];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,97.6,173.9), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("ApAO7IAA91ISBAAIAAd1g");
	mask_3.setTransform(57.675,95.525);

	// Layer_3
	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgVg+QAEAKASAXQAQAUADAQQADAOgBAQQgBAUgJAG");
	this.shape_88.setTransform(32.8375,57.875);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AnnrPQAAABAIAjQAFAaAGAKQAJAPALAWQASAjASA6QALAkAWAbQASAVAkAaQAhAYAJAMIAIAKQACAMAJARQANAZACAFQAMAcAVAgQADADAlBBQAYApCKC6QAVAeAvBMQAuBMAbAjQBsCSCFCiQBxCLAHAD");
	this.shape_89.setTransform(53.25,118.575);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ABMAuQADAQgFANQgGAOgPAHQgVALgUgFQgNgEgXgQIgMgKQgVgWgLgeQgMgfAGgcQAEgWALgRQAOgVASgDQASgDAUAW");
	this.shape_90.setTransform(8.1816,39.3286);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhPgkQgGgVAMgTQALgRAVgJQAbgKATAPQANAKATAeQAcAuAHASQARAogLAfQgLAggggDQgdgDgUgaQgGgHgZglQgRgYgDgKQgLgdgDgHg");
	this.shape_91.setTransform(17.4292,34.3965);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhZg7QAAggBFgMQAVgFAPAJQAMAGAOAVQAdArAKAYQARArgQAhQgKAVgYAKQgZALgNgS");
	this.shape_92.setTransform(24.8319,29.5405);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ag0CHQABgHgHgfQgHgcgFgMQgFgNgLghQgJgegGgPQgIgRgEgTQgGgZAEgOQAIgcAUgJQAJgFAJAAQAiAAAbA2QAOAeAUA2QADAEAMAbQAIATAIAMQAEAGAOASQALAPAGAKQACADAIAaQAGATAJAG");
	this.shape_93.setTransform(38.5158,15.6727);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AkDBNQACgNAZgYQAtgpAZgRQAwgiBagIQATgBA/gKQA8gIAWAFQAYAHAoASQAqATAOAN");
	this.shape_94.setTransform(67.675,95.888);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Am9hsQASguAtgqQAQgPBFg2QAdgVARgIQAWgJAggCQAygDA5AHQBMAIAZAVQAHAGAPAMQANALAHAKQAFAIAIATQAIATAGAIQAJAMAPAWQAOATAIAQQAJAVAYAXQANANAbAaQANAOAbAYQAdAcALAMQAkAlASAVQAdAiASAfQAIAPAOA9QAJAoAjAR");
	this.shape_95.setTransform(70.275,93.2653);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgmgCQARgKAWAGQANAEAZAL");
	this.shape_96.setTransform(60.8,59.322);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ag0h/QADADAcAXQAUARAGANQAKASADAcQABAQABAeQABAgAIAYQAIAXAQAc");
	this.shape_97.setTransform(65.375,34.675);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAAheQgbBAAPA5QAFATAHATQAKAaAIAE");
	this.shape_98.setTransform(43.7384,53.55);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiuguQAKgRAUgKQAigRADgCQAPgLAJgRQAGgKAKgZQAIgSAWgaQAXgcAQgJQA0gdAxAFQASABASALQAQAKAMAOQAGAJACARQABALgLAOQgDAEgQAQQgfAfgRAVQgYAegNAeQgLAagEAmQgCAWgCAtQgCAVgEAvQgHAngZANQgTALgIAVQgHAUAEAA");
	this.shape_99.setTransform(66.8792,37.4698);

	var maskedShapeInstanceList = [this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92,this.shape_93,this.shape_94,this.shape_95,this.shape_96,this.shape_97,this.shape_98,this.shape_99];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0,0,115.4,191.1), null);


(lib.ClipGroup_5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AwTHyICSzKIeVDnIiSTKg");
	mask.setTransform(104.375,72.875);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAdQgLgCgIgJQgHgJABgLQABgMAKgIQAJgHALABQAMACAIAJQAHAKgBAKQgCAMgJAIQgIAGgKAAIgDAAgAgOgSQgIAGgBAKQgBAJAGAIQAHAIAJABQAJABAIgGQAHgGABgKQABgJgGgIQgFgHgKgBIgDgBQgHAAgHAFgAAGARIgGgPIgFgBIgCAOIgFgBIAEgeIAQACIAEACQADADAAAEQgBAIgKgBIAIAPgAgFgDIAKABQAFABgBgEQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAgBIgCgBIgKgBg");
	this.shape.setTransform(195.725,36.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E31D25").s().p("AgzDaQgXgKgNgUQgSgbAEgnIAVikIgiAEIAFgnICCiQIAjgEIgLBZIBGgJIgKBPIhHAJIgSCGQgCAYAAAKQABAMAEAGQAMANAZgMQAMgHASgOQgCAqgRAdQgQAdgjAMQgQAFgPAAQgSAAgSgIg");
	this.shape_1.setTransform(94.15,74.6841);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E31D25").s().p("AhuDFQgagMgLgnQgNgnANgjQAJgYAMgQQANgTAXgQQALgHAxgbQAlgVAJgNQAJgNgDgNQgEgNgPACQgWADgrAgQgWAQgoAjIAMhiQAVgaAZgVQAjgbAfgIQA2gMAqAeQArAfgFA1IgVCwQgBANAPAAQAPAAAMgMQgBANgFASQgGAVgHAOQgTAmggAJQggAIgggZQghAbgkAFIgRABQgXAAgVgJgAgVAyQgWATgEAOQgEAPAGAKQAFAIAIADQAJADAKgFQALgFACgNIAKhIQgPAJgQAOg");
	this.shape_2.setTransform(152.9186,69.9961);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E31D25").s().p("ApxHiQiOg9hVhcQhYhfgPhzQgRiMBiiLIADAEQALAMAMAJQhQB8APB9QATCTCOBuIBJpdIAFgCQA3gNBHgIIgZDVID1m1IguAQIgBgbQCRgxChgUQGLgyEsCCQCOA9BVBcQBYBfAPBzQAOByg+BxQg8Buh6BeQkEDImMAxQhsAOhmAAQkMAAjZhegAhCoZIg8AJIl1JXIEHHaQBcAHBdgEICExIQhEAChPAJgABYIXQCFgTB8goIjNl4gAmOILIjHleIgjEQQBoAyCCAcgADvgPIDxG4QDXhgB2iPQB4iTgTiYQgIg8gdg3IgBgCQgvhXhghEQhfhDiEgqgACniaIC9l4QhAgLhOgFgALGCFQgWgKgOgTQgSgcAEgmIAVilIgjAEIAGgnICEiRIAigEIgMBaIAAACIBHgJIgKBOIhHAJIgRCHQgDAXAAAKQAAAMAFAFQAMAOAYgNQANgHASgOQAAAngTAgQgRAdghAMQgQAGgQAAQgTAAgSgJg");
	this.shape_3.setTransform(104.3798,72.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E31D25").s().p("AgRA/QgWgDgKgVQgKgVAHgYQAHgbAVgQQAWgQAUADQAWAEAKAUQAKAVgHAZQgIAagUAQQgSANgRAAIgHAAg");
	this.shape_4.setTransform(76.5871,60.8181);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E31D25").s().p("AgqhoIB1g2IglEwIhwANg");
	this.shape_5.setTransform(73.775,83.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ai1DdQgUgMgQgSIAAAAQg9hDABhcIABgOQADguATgsQAUgtAigjQAeggAlgUQAlgTAogEQAigDAkANQAlANAeAZQAhgiAlgCQAVgBAiAMIABAAQASAHAHAAQAIABAFgFQAGgHAJADQAJACACAKQAIArAAAhIgDAkQgGAvgWAjQgWAmgoAYQgkAVgsAGQhJAIg2ANQg6ANgqBCQgRAcgIAGQgHAEgHAAQgKAAgLgHg");
	this.shape_6.setTransform(39.0492,38.1101);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ApkHYQiLg8hThaQhWhdgOhwQgOhwA9hvQA6hrB4hdQD+jDGDgwQGDgxEmB/QCLA8BTBaQBWBdAOBwQAOBwg8BvQg7Brh4BdQj+DDmDAwQhqAOhkAAQkGAAjVhcg");
	this.shape_7.setTransform(104.3759,72.875);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_1, new cjs.Rectangle(8.6,15.3,191.6,115.2), null);


(lib.ClipGroup_4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AqHHyQiTg/hYhfQhbhigPh3QgUibB0iXIASAXQhiCKARCNQAPByBYBfQBVBcCOA9QEsCCGLgxQGMgyEEjHQB6hfA8huQA+hwgOhzQgPhyhYhfQhVhciOg9QksiCmLAxQihAUiRAxIgCgVQCRgvCggUQBmgNBpAAQBeAABXAKQEYAhC3B7QC8B+AWCzQAPB2hBB1Qg+Byh+BiQkNDOmZAzQhxAOhpAAQkVAAjhhhg");
	mask.setTransform(115.2195,86.688);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F3F9FC","#F3F9FC","#B0B9BE","#F3F9FC","#F3F9FC","#D6E1E7","#B0B9BE","#F3F9FC","#F3F9FC"],[0,0.18,0.31,0.396,0.506,0.588,0.808,0.992,1],-98.5,-11.6,95.7,11.4).s().p("AyNJtICz3ZMAhoAEAIizXZg");
	this.shape.setTransform(116.575,87.725);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_1, new cjs.Rectangle(16.1,27.2,198.3,119.10000000000001), null);


(lib.ClipGroup_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AwTHyICSzKIeVDnIiSTKg");
	mask.setTransform(104.375,72.875);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AqHHzQiThAhYhfQhbhigPh2QgUibB0iYIASAXQhiCLARCMQAPBzBYBfQBVBcCOA9QEsCCGLgyQGMgxEEjIQB6heA8huQA+hxgOhyQgPhzhYhfQhVhciOg9QksiCmLAyQihAUiRAxIgCgVQCRgwCggUQGZgzE3CGQCTBABYBfQBbBiAPB2QAPB3hBB1Qg+Bxh+BiQkNDPmZAzQhxAOhpAAQkVAAjhhhg");
	this.shape.setTransform(104.3695,72.875);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_1, new cjs.Rectangle(5.2,13.3,198.4,119.2), null);


(lib.ClipGroup_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkFAtIAAgNQADgrASgrQASgqAegjQAdgfAjgTQAigRAjgFIAPgBQAgABAgAOQAiAOAaAYIAAAAIABAAQAegnAigFQATgCAjALQAVAIAIAAQAPABAKgKQAIAkABAlQABASgDAQQgEAtgUAhQgVAkgjAVQghAUgpAGQiCARhKAhQg5AagkAvQhFhAgBhfg");
	mask.setTransform(26.2143,20.45);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E31D25").s().p("AkFAtIAAgMQADgsASgrQASgqAegiQAdggAjgTQAigRAjgFQARgBAPACQAbADAdANQAcAOAXAVIAAAAIABAAQAmgxAtAGQAMABAXAIQATAGAHABQASABAKgLQAIAlABAlQABASgDAQQgEAtgUAhQgVAkgjAVQghAUgpAGQiCARhKAhQg5AagkAwQhFhBgBhfg");
	this.shape.setTransform(26.2143,20.4429);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkFAtIAAgMQADgsASgrQASgqAegiQAdggAjgTQAigRAjgFQARgBAPACQAbADAdANQAcAOAXAVIAAAAIABAAQAmgxAtAGQAMABAXAIQATAGAHABQASABAKgLQAIAlABAlQABASgDAQQgEAtgUAhQgVAkgjAVQghAUgpAGQiCARhKAhQg5AagkAwQhFhBgBhfg");
	this.shape_1.setTransform(26.2143,20.4429);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_1, new cjs.Rectangle(0,0,52.5,40.9), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AxFMlIAA5JMAiKAAAIAAZJg");
	mask_1.setTransform(109.35,80.5);

	// Layer_3
	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgDAdQgMgBgHgKQgHgJABgLQABgMAKgIQAJgHALABQAMACAIAJQAHAKgBALQgCAMgJAHQgIAGgKAAIgDAAgAgOgRQgIAGgBAJQgBAJAGAIQAHAIAJABQAJABAIgGQAHgGABgKQABgJgGgIQgFgHgKgBIgDgBQgHAAgHAGgAAGARIgHgPIgEgBIgCAOIgFgBIAEgeIAQACIAEACQADADAAAEQgBAIgKgBIAIAPgAgFgDIAKACQAFAAgBgEQABgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAIgCAAIgKgCg");
	this.shape_84.setTransform(71.8063,22.8438);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AjFAZQBkg2CFgBQBAABAXgFQAsgHAigdQgWAkgtALQgXAGhKAEQiXAKhVBKg");
	this.shape_85.setTransform(42.55,50.15);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgZAsQgJgGABgLIAAgBQAAgEAEgCIAGgBQAJgBAAAEQADAJALgCQANgCAAgKQABgFgIgCIgQgCQgUgEABgSQABgOAKgJQAJgJAOgCQANgBAJAGQAIAGgBALQAAAEgEAAIgJACQgEAAAAgDQgDgIgLACQgKACgBAJQAAAFAIABIARADQARADgBATQgBAPgMAKQgJAIgMACIgHABQgKAAgHgFg");
	this.shape_86.setTransform(45.3508,40.5707);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("Ah+BSQgDgDABgDIAIh/QABgJAIgBIAPgCQAJgBADAHIAjBSIAFhTQAAgEADgCQACgDADAAIChgQQAFAAgBAFIAAAIQAAAFgFABIiSAPIgHBqQgBAJgIABIgNADQgHABgEgHIgkhRIgFBYQgBAIgIACIgIACIgCABQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_87.setTransform(35.9292,40.7643);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgcAjQgJgMACgTQABgSALgNQALgPAQgCQASgBAIAMQAIALgCASQAAAHgGAAIguAGQAAAIAEAFQAFAFAHgBQAIgCAGgKQACgDADAAIALgBQAAgBABAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAABAAQAAABAAAAQAAAAAAABQgBAAAAABQgCALgLAJQgKAJgKACIgGAAQgNAAgIgKgAADgaQgGABgFAFQgFAFgBAIIAggEQAAgHgEgEQgEgEgGAAIgBAAg");
	this.shape_88.setTransform(59.6268,38.5878);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgeApQgKgNACgWQABgVAMgQQAMgSARgCQATgCAJAOQAIAMgBAVQAAAHgHABIgxAJQAAAJAEAFQAFAGAIgCQAJgBAGgLQACgEADAAIAMgCQAEgBgBAGQgEANgKAKQgLAKgMACIgHABQgNAAgIgLgAADgeQgGABgGAGQgGAGgBAJIAjgGQAAgIgEgFQgEgDgGAAIgCAAg");
	this.shape_89.setTransform(37.8521,41.5671);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgMA4QgGgIABgMIADgrIgEAAQgEAAAAgEIABgIQABgFADAAIAFgBIACgbQABgHAFgBIAHgBQABAAAAAAQABAAABAAQAAABAAAAQABAAAAABQACACgBADIgCAbIANgCQAEAAAAAFIgBAHQgBAFgDABIgNABIgDAoQgBANALgBIABgBQAFAAgBAFIgBAIQAAAFgEABIgIABIgEABQgHAAgFgGg");
	this.shape_90.setTransform(51.125,38.0661);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AggAJIABgFQAAgEADAAIA5gLQAAgBABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABIgBAHQgBAGgEAAIg4AGQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAgBg");
	this.shape_91.setTransform(60.1813,32.045);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgMA3IAHhqQAAgHAFgBIAHgBQABAAABAAQAAAAABABQAAAAABAAQAAABAAAAQABABAAAAQABABAAAAQAAABAAAAQAAABAAABIgHBpQgBAHgFABIgHABIgBAAQgEAAAAgGg");
	this.shape_92.setTransform(54.555,37.6813);

	var maskedShapeInstanceList = [this.shape_84,this.shape_85,this.shape_86,this.shape_87,this.shape_88,this.shape_89,this.shape_90,this.shape_91,this.shape_92];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(22.5,19.9,52.3,37.4), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	mask_4.setTransform(150,300);

	// Layer_3
	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgrBBIAmhAIgcAAIAKhBIBDAAIgJA9IgyBEg");
	this.shape_100.setTransform(237.325,220.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AhNBGQgYgbAAgsQAAgwAfgcQAbgYArAAQAqAAAaATQAYARAJAcIhBAJQgCgMgJgHQgIgHgNAAQgMAAgIAJQgHAIAAAQIAyAAIAAAmIgyAAIAAAJQABAMAEAGQAJALAOAAQANAAAJgJQAHgIABgJIBDAJQgHAfgdASQgZAPglAAQg1AAgcggg");
	this.shape_101.setTransform(261.475,210.575);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AhYBTQgPgPAAgXQAAgdAWgRQAagVBCgGIAOgBIAAgDQAAgMgEgFQgFgFgOAAQgaAAgDAVIhGgHQAIgeAZgQQAYgPAtAAQAfAAASAFQAaAIALAVQAIAOAAAgIAABMQAAAYAFATIhIAAQgDgKAAgRQgUAfgrAAQgjAAgTgTgAAOAIQgPADgOAHQgKAIAAAMQAAARAVAAQAdAAAAgmIAAgLg");
	this.shape_102.setTransform(220.275,210.575);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AhshWIB3gTQAigFAQAJQAUAJAEAZQACATgJANQgJANgPAFIAAAAQAUgBAPAKQAQAKAEAUQACANgEANQgEAMgJAIQgJAKgQAFIgcAGIh3ASgAAEANIgTAEIAHApIATgEQALgBAGgHQAFgHgCgJQgBgLgJgEQgFgCgHAAIgFAAgAgOg+IgNACIAGAoIAOgCQALgCAFgGQAFgHgBgJQgBgKgJgFQgDgCgGAAIgIABg");
	this.shape_103.setTransform(197.5833,212.2074);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AhkCEIAAkDIBHAAIAAAdIABAAQAIgMAKgJQAQgMAZABQAfAAAUAaQATAbAAAvQAAAwgUAbQgVAcgiAAQgQAAgMgGQgNgHgIgMIAAAAIAABUgAgRhLQgGAGAAARIAAArQAAARAEAIQAGAKALAAQAOAAAHgRQAEgKAAgbQAAgbgFgMQgHgOgNAAQgJAAgGAGg");
	this.shape_104.setTransform(174.825,211.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AhJBMQgfgdAAgvQABgxAhgdQAdgXArAAQAvAAAbAdQAdAeAAAvIAAAMIiDAAQAAAQAHAKQAJAMAOAAQAOAAAHgHQAIgIAAgKIBGAEQgGAegaATQgbATgsAAQgsAAgdgagAgRguQgJAKAAAPIA3AAQABgPgIgKQgGgIgOAAQgMAAgHAIg");
	this.shape_105.setTransform(151.15,213.425);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AhthuIBFgOIAGAbIAAAAQAFgOAJgKQAOgOAXgFQAfgHAZAWQAYAXAJAuQAKAwgOAeQgPAgghAGQgQAEgOgFQgPgDgJgLIAAABIAQBRIhKAQgAgFhVQgIABgFAHQgFAIADARIAJAqQAEASAFAFQAIAJAKgCQAOgDAEgRQACgKgFgdQgGgagHgLQgHgKgLAAIgFABg");
	this.shape_106.setTransform(128.217,211.2759);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AhJBMQgfgeAAguQAAgxAjgdQAcgYArABQAuAAAdAdQAcAeAAAvIAAAMIiDAAQgBAQAIALQAJALAOAAQANAAAIgIQAHgHABgLIBGAFQgGAfgaARQgcAVgrAAQgtAAgcgbgAgRgtQgKAJABAQIA3AAQACgQgJgJQgHgKgNAAQgLAAgIAKg");
	this.shape_107.setTransform(105.925,215.7);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AAVBjIAAiRIgpAAIAACRIhMAAIAAjFIDBAAIAADFg");
	this.shape_108.setTransform(82.575,210.55);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AhSBnQgkglAAhBQAAg7AagiQAggrA+AAQAzAAAfAaQAaAWAIAlIhJANQgEgPgGgJQgKgQgVAAQgSAAgKAPQgIANAAAUIA+AAIAAA3Ig+AAQAAATAHANQAKASAWAAQARAAALgLQAKgKABgLIBJAOQgGAjgbAUQgcAXg1AAQg2AAghghg");
	this.shape_109.setTransform(42.325,207.225);

	var maskedShapeInstanceList = [this.shape_100,this.shape_101,this.shape_102,this.shape_103,this.shape_104,this.shape_105,this.shape_106,this.shape_107,this.shape_108,this.shape_109];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(30.5,193.7,241.2,33.400000000000006), null);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_1_1();
	this.instance.parent = this;
	this.instance.setTransform(2.55,1.5,1,1,0,0,0,109.4,80.5);

	this.instance_1 = new lib.ClipGroup_2_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-65.1,-35.1,1,1,0,0,0,26.2,20.4);

	this.instance_2 = new lib.ClipGroup_3_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0.05,0.05,1,1,0,0,0,104.4,72.9);

	this.instance_3 = new lib.ClipGroup_4_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1.3,1.1,1,1,0,0,0,116.5,87.7);

	this.instance_4 = new lib.ClipGroup_5_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0.05,0.05,1,1,0,0,0,104.4,72.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115.2,-86.6,233.2,175.5);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_7();
	this.instance.parent = this;
	this.instance.setTransform(-1.05,88.15,1,1,0,0,0,150,300);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Agdh9IA6ghIgLE9g");
	this.shape.setTransform(-82.9,-8.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhUggICpAhIg2Agg");
	this.shape_1.setTransform(49.025,20.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiNgcIEbACIggA3g");
	this.shape_2.setTransform(54.025,17.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151,-211.8,300,600);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_4();
	this.instance.parent = this;
	this.instance.setTransform(271.5,196.5,1.4,1.4,0,0,0,61.5,82.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},9).wait(8).to({_off:false},0).to({_off:true},19).wait(8).to({_off:false},0).to({_off:true},17).wait(8).to({_off:false},0).wait(14).to({_off:true},1).wait(16));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AlmAHQAKAAABgGQABgGADgEQACgEAFgDQAFgDACgCQADgDACgHQACgIACgDQACgDAGgDQAFgDACgDQACgDACgHQABgHACgDQALgIAEgFQABgGACgDQACgCAEgBQAEgBACgCQAFgEADgGQAEgFACgEQAHgIAEgGQADgCADgIQAEgHADgDQAMgIAGgIQANgUAHgJQAHgHADgDQAFgHAAgGQAKAAAQASQACACAUAYQAJAKAIAWQAMAeACAEIACAFQAHAIARAMQARANAHAHQAOANARANQABAAAeAWQAUANAzAkQAtAgAaARQBWA3AqAgQAMAJAbATQAYARAMAO");
	this.shape.setTransform(194.1789,51.6234,1.3999,1.3999);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AlGjaQAIAFAQARQAPAQALAGQAMAHAQADQAKACAUAEQAaAFAeAVQARANAfAbQACABAcAVQARAOANAIQAfATAsAjQAwAlBzBMQAaARA3AoQALAHAVANQATAMALAL");
	this.shape_1.setTransform(189.5242,83.6824,1.3999,1.3999);

	this.instance_1 = new lib.ClipGroup_6();
	this.instance_1.parent = this;
	this.instance_1.setTransform(285.85,173.55,1.4,1.4,0,0,0,57.7,95.5);

	this.instance_2 = new lib.ClipGroup_5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(273.4,167.95,1.4,1.4,0,0,0,48.8,87);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{y:83.6824}},{t:this.shape,p:{y:51.6234}}]}).to({state:[{t:this.shape_1,p:{y:63.4324}},{t:this.shape,p:{y:31.3734}}]},9).to({state:[]},2).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.shape_1,p:{y:83.6824}},{t:this.shape,p:{y:51.6234}}]},2).to({state:[{t:this.shape_1,p:{y:63.4324}},{t:this.shape,p:{y:31.3734}}]},19).to({state:[]},2).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.shape_1,p:{y:83.6824}},{t:this.shape,p:{y:51.6234}}]},2).to({state:[{t:this.shape_1,p:{y:63.4324}},{t:this.shape,p:{y:31.3734}}]},17).to({state:[]},2).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.shape_1,p:{y:83.6824}},{t:this.shape,p:{y:51.6234}}]},2).to({state:[{t:this.shape_1,p:{y:83.6824}},{t:this.shape,p:{y:51.6234}}]},14).to({state:[]},1).wait(16));

	// Layer_10 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AkPHvIivhlIjWiEIgzkMQgykSADgbQADgfCIh4QCHh3AjgFQAcgEFEAiIFHAjQAIAAEGEmIEDEkIhTCzIgzAOIgrATIgpAlIgOAYIgFATIASAyIgHAYIgOAbIgQASQgKAIgIABIgVADIgggJIgigcIhUgwIgogmIgvggIgYgNIgdgKQgCgCglAUIgkAVIgSAbQgTAdgBAKQgDAQgZAjIiTByIidhZg");
	var mask_graphics_9 = new cjs.Graphics().p("AFXGjIlWjqIhShBIgqgYIiziGIgfgRIhrgcIg/g+IAMgJIAHgSIAWgUIANgbIAUgWIALgYIAZgcIAVgNIAYgfIAUglIAZgUIABgCIAogyIAQgWIAOADIAlAmIAbArIAdBJICABlIFsD5ICLBoIANAYIgBA0IgKA2Ig1BkIgNApIgGAnIgMAQg");
	var mask_graphics_13 = new cjs.Graphics().p("A18ICQGxnuAAAHIBrgoIAlANIA8AIIApgSIAZgyIAWgJIAWAJIAmAJIAcgSIAQggIAJgdIAcAHIAvgTIAWgWIAQgyIgyiUIHQpzIKuClQKuCqAAANQAAALAtDiQAoD1gTBzQggC4vHK5Qg1Ago+A/Io1A7g");
	var mask_graphics_15 = new cjs.Graphics().p("AKvIUIg0gcIhrhxIgTADIgsAqIgaAnImdAPQmgAOgQgDQgRgDiijZQh9iogzhKQgPgVBFkSQAiiKAliFIJ7gHQA7AADsAdQEAAgAMARQALAQApDnQAVB0ASBvIAIA6IApBOIAVB9IAiA8IAIAqIgCBBIgiBZg");
	var mask_graphics_17 = new cjs.Graphics().p("AkPHvIivhlIjWiEIgzkMQgykSADgbQADgfCIh4QCHh3AjgFQAcgEFEAiIFHAjQAIAAEGEmIEDEkIhTCzIgzAOIgrATIgpAlIgOAYIgFATIASAyIgHAYIgOAbIgQASQgKAIgIABIgVADIgggJIgigcIhUgwIgogmIgvggIgYgNIgdgKQgCgCglAUIgkAVIgSAbQgTAdgBAKQgDAQgZAjIiTByIidhZg");
	var mask_graphics_36 = new cjs.Graphics().p("AFXGjIlWjqIhShBIgqgYIiziGIgfgRIhrgcIg/g+IAMgJIAHgSIAWgUIANgbIAUgWIALgYIAZgcIAVgNIAYgfIAUglIAZgUIABgCIAogyIAQgWIAOADIAlAmIAbArIAdBJICABlIFsD5ICLBoIANAYIgBA0IgKA2Ig1BkIgNApIgGAnIgMAQg");
	var mask_graphics_40 = new cjs.Graphics().p("A18ICQGxnuAAAHIBrgoIAlANIA8AIIApgSIAZgyIAWgJIAWAJIAmAJIAcgSIAQggIAJgdIAcAHIAvgTIAWgWIAQgyIgyiUIHQpzIKuClQKuCqAAANQAAALAtDiQAoD1gTBzQggC4vHK5Qg1Ago+A/Io1A7g");
	var mask_graphics_42 = new cjs.Graphics().p("AKvIUIg0gcIhrhxIgTADIgsAqIgaAnImdAPQmgAOgQgDQgRgDiijZQh9iogzhKQgPgVBFkSQAiiKAliFIJ7gHQA7AADsAdQEAAgAMARQALAQApDnQAVB0ASBvIAIA6IApBOIAVB9IAiA8IAIAqIgCBBIgiBZg");
	var mask_graphics_44 = new cjs.Graphics().p("AkPHvIivhlIjWiEIgzkMQgykSADgbQADgfCIh4QCHh3AjgFQAcgEFEAiIFHAjQAIAAEGEmIEDEkIhTCzIgzAOIgrATIgpAlIgOAYIgFATIASAyIgHAYIgOAbIgQASQgKAIgIABIgVADIgggJIgigcIhUgwIgogmIgvggIgYgNIgdgKQgCgCglAUIgkAVIgSAbQgTAdgBAKQgDAQgZAjIiTByIidhZg");
	var mask_graphics_61 = new cjs.Graphics().p("AFXGjIlWjqIhShBIgqgYIiziGIgfgRIhrgcIg/g+IAMgJIAHgSIAWgUIANgbIAUgWIALgYIAZgcIAVgNIAYgfIAUglIAZgUIABgCIAogyIAQgWIAOADIAlAmIAbArIAdBJICABlIFsD5ICLBoIANAYIgBA0IgKA2Ig1BkIgNApIgGAnIgMAQg");
	var mask_graphics_65 = new cjs.Graphics().p("A18ICQGxnuAAAHIBrgoIAlANIA8AIIApgSIAZgyIAWgJIAWAJIAmAJIAcgSIAQggIAJgdIAcAHIAvgTIAWgWIAQgyIgyiUIHQpzIKuClQKuCqAAANQAAALAtDiQAoD1gTBzQggC4vHK5Qg1Ago+A/Io1A7g");
	var mask_graphics_67 = new cjs.Graphics().p("AKvIUIg0gcIhrhxIgTADIgsAqIgaAnImdAPQmgAOgQgDQgRgDiijZQh9iogzhKQgPgVBFkSQAiiKAliFIJ7gHQA7AADsAdQEAAgAMARQALAQApDnQAVB0ASBvIAIA6IApBOIAVB9IAiA8IAIAqIgCBBIgiBZg");
	var mask_graphics_69 = new cjs.Graphics().p("AkPHvIivhlIjWiEIgzkMQgykSADgbQADgfCIh4QCHh3AjgFQAcgEFEAiIFHAjQAIAAEGEmIEDEkIhTCzIgzAOIgrATIgpAlIgOAYIgFATIASAyIgHAYIgOAbIgQASQgKAIgIABIgVADIgggJIgigcIhUgwIgogmIgvggIgYgNIgdgKQgCgCglAUIgkAVIgSAbQgTAdgBAKQgDAQgZAjIiTByIidhZg");
	var mask_graphics_83 = new cjs.Graphics().p("AkPHvIivhlIjWiEIgzkMQgykSADgbQADgfCIh4QCHh3AjgFQAcgEFEAiIFHAjQAIAAEGEmIEDEkIhTCzIgzAOIgrATIgpAlIgOAYIgFATIASAyIgHAYIgOAbIgQASQgKAIgIABIgVADIgggJIgigcIhUgwIgogmIgvggIgYgNIgdgKQgCgCglAUIgkAVIgSAbQgTAdgBAKQgDAQgZAjIiTByIidhZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:179.5165,y:57.2792}).wait(9).to({graphics:mask_graphics_9,x:194.25,y:47.35}).wait(2).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_13,x:298.1669,y:108.2}).wait(2).to({graphics:mask_graphics_15,x:161.6483,y:44.175}).wait(2).to({graphics:mask_graphics_17,x:179.5165,y:57.2792}).wait(19).to({graphics:mask_graphics_36,x:194.25,y:47.35}).wait(2).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_40,x:298.1669,y:108.2}).wait(2).to({graphics:mask_graphics_42,x:161.6483,y:44.175}).wait(2).to({graphics:mask_graphics_44,x:179.5165,y:57.2792}).wait(17).to({graphics:mask_graphics_61,x:194.25,y:47.35}).wait(2).to({graphics:null,x:0,y:0}).wait(2).to({graphics:mask_graphics_65,x:298.1669,y:108.2}).wait(2).to({graphics:mask_graphics_67,x:161.6483,y:44.175}).wait(2).to({graphics:mask_graphics_69,x:179.5165,y:57.2792}).wait(14).to({graphics:mask_graphics_83,x:179.5165,y:57.2792}).wait(1).to({graphics:null,x:0,y:0}).wait(16));

	// _Clip_Group_
	this.instance_3 = new lib.Symbol2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(217.6,82.25,0.3096,0.3096,36.0855,0,0,250.6,86.7);

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({y:62},0).wait(2).to({regX:250.5,regY:86.9,rotation:-49.335,x:244.1,y:90.85},0).wait(2).to({regX:250.3,rotation:-225.3554,x:251.1,y:96.8},0).wait(2).to({regX:250.4,rotation:-317.8686,x:212.15,y:65.25},0).wait(2).to({regX:250.6,regY:86.7,rotation:-323.9145,x:217.6,y:82.25},0).wait(19).to({y:62},0).wait(2).to({regX:250.5,regY:86.9,rotation:-409.335,x:244.1,y:90.85},0).wait(2).to({regX:250.3,rotation:-585.3554,x:251.1,y:96.8},0).wait(2).to({regX:250.4,rotation:-677.8686,x:212.15,y:65.25},0).wait(2).to({regX:250.6,regY:86.7,rotation:-683.9145,x:217.6,y:82.25},0).wait(17).to({y:62},0).wait(2).to({regX:250.5,regY:86.9,rotation:-769.335,x:244.1,y:90.85},0).wait(2).to({regX:250.3,rotation:-945.3554,x:251.1,y:96.8},0).wait(2).to({regX:250.4,rotation:-1037.8686,x:212.15,y:65.25},0).wait(2).to({regX:250.6,regY:86.7,rotation:-1043.9145,x:217.6,y:82.25},0).wait(14).to({startPosition:0},0).to({_off:true},1).wait(16));

	// Layer_4
	this.instance_4 = new lib.ClipGroup_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(271.5,196.5,1.4,1.4,0,0,0,61.5,82.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAMgoQAIARgLAaQgJAXgOAP");
	this.shape_2.setTransform(300.7946,94.3356,1.3999,1.3999);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgKgnQAPAXAEANQAEAJgCAMQgDAUAAAC");
	this.shape_3.setTransform(290.367,85.4812,1.3999,1.3999);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgQgdQAPAEAJAUQAKASgBAR");
	this.shape_4.setTransform(272.4389,78.5516,1.3999,1.3999);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AAHgYQgOgOgHAOQgHAMADAYQABALAOAGQANAGAKgJ");
	this.shape_5.setTransform(292.9829,67.5202,1.3999,1.3999);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgYgeQgIAOAIATQAIAUAQAHQAFADAKgDQAMgEACgH");
	this.shape_6.setTransform(258.4596,56.2848,1.3999,1.3999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AARgeQgVgWgOAUQgOAUANAiQAGAQAPAEQARAEAHgX");
	this.shape_7.setTransform(280.8405,58.4078,1.3999,1.3999);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgfgDQAQgJASAEQARACAMAR");
	this.shape_8.setTransform(288.6712,58.1113,1.3999,1.3999);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgdgOQAGAAAOAAQALABALAGQAGAEAFAIQADAEADAG");
	this.shape_9.setTransform(284.9615,38.3389,1.3999,1.3999);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgwgCQAcgOAlAPQAFABAKACQAKAEAIAE");
	this.shape_10.setTransform(275.6873,47.8227,1.3999,1.3999);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgnAAQASgIAZAAQAgAAADAS");
	this.shape_11.setTransform(273.7974,30.7444,1.3999,1.3999);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgHiRQgJAaAIApQAIAwgBATQgBALgEATQgCATACAMQACAJALApQAKAngJAG");
	this.shape_12.setTransform(268.5497,40.0538,1.3999,1.3999);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AjcgkQAxgKAHgBQAggGAaADQAHABAHAFQAJAHAFABQAOAEAigEQAegDAhAFQAlAEAYALQAGADAHAGQAIAHAFADQAIADALADQAGACANADQAQAEAUANQAUANAHAL");
	this.shape_13.setTransform(273.7624,117.7646,1.3999,1.3999);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ai2hcQADAXACAGQAFAPAMAGQAQAJAdAKQAPAGAfAKQAhAMA1AZQA+AbAZALQAHADAfAQQAfAMAKgK");
	this.shape_14.setTransform(280.1319,103.5189,1.3999,1.3999);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgoCSQAIABAGgHQAHgJAEgXQADgSAGgSQALghAGgLQADgGAIgMQAIgLADgHQAIgPAAgqQABg4gJgZ");
	this.shape_15.setTransform(239.0522,75.83,1.3999,1.3999);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgSgYQgDANAOAPQAJAMARAJ");
	this.shape_16.setTransform(230.6427,92.8307,1.3999,1.3999);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AglAJQARAFAZgFQAfgFACgO");
	this.shape_17.setTransform(229.876,112.3338,1.3999,1.3999);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AiXBEQALgIApglQAegbAcgKQBNgfAegJQA4gRAeAF");
	this.shape_18.setTransform(272.3626,164.7556,1.3999,1.3999);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AjQBMQAVgLAeggQAegfAWgKQAWgLA6gTQA5gSAYgFQAugIAVgBQAOgBAegDQAbgCAQAE");
	this.shape_19.setTransform(283.8066,169.2896,1.3999,1.3999);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AFvkZQgHgIgPgXQgNgVgKgKQgLgMghgYQgPgLgCgCQgHgHgGgJQgCgDgWhDQgNgnghgFIglgBQgZgRgagHQgWgGgkAAQhWAAgxAGQhNAJg2AZQghAQgHAEQgWALgPAMQgUAQgRAVQgYAeAJAPIAEADQAHAHAXAMQASAJAGAOQAGALAJAaQADAHAOAWQARAaAIANQBfCmD8FIQB/CkBtCG");
	this.shape_20.setTransform(288.2682,212.0337,1.3999,1.3999);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgDgYQAGAQABASIAAAP");
	this.shape_21.setTransform(303.0201,131.3635,1.3999,1.3999);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgdAqQgMgQgHgTQgKgbAQgEQAAgPAVgCQARgBAMAFQAPAGAOARQABABAHAKQACACAEADQADAEgDgB");
	this.shape_22.setTransform(254.2045,136.4157,1.3999,1.3999);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgbgyQAJAHAKARQAGAKAJASQAGAJAGARQABACAEAKQAGAPgDgG");
	this.shape_23.setTransform(245.901,122.9998,1.3999,1.3999);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("ACyAcQABAQABAdQAAAFAFAhQAEAZgEAMQgJAAgNgGQgOgIgHgDQgOgHgegKQgfgKgOgHQhHglgmgPQgdgLgMgFQgWgJgSgKIgHgGQgYgLgMghQgNgiAPgVQAUgcAYgNQAegRAbAKQADACAMAHQAJAGAGABQALACATgEQAVgEAJAAQAdAAAUAaQAIALAEADQAGAFAJACQAqAIAUAZQAWAaAHANQgDAOABAcg");
	this.shape_24.setTransform(278.0296,92.6201,1.3999,1.3999);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AkAhtQgIBYAnAjQANAMARgCQALgCAYgGQAugFAUAAQAMAAAVAFQAWAGAKABQAMABAjAAQAeABASACQAVADAEAAQANADAKAEQAHADANAIQANAHAIADQAIAEAqAPQAlAQgCARQANgHACgJQABgDgBgWQACgWABgNQACgWgMgI");
	this.shape_25.setTransform(269.5045,112.3946,1.3999,1.3999);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhXjeQgFAKgLASQgIAPgBAOQAAAIADAHQAAABAIAMQAMATABAbQABATACAfQADAaAMASQATAdAkAgQAPAOARATQALAMAUAYQAPASAhAgQAKAKACADQABADACAMQABAKABAC");
	this.shape_26.setTransform(230.5359,113.8295,1.3999,1.3999);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AgriMQAXASAKAXQAIARAEAfQAGAmAPAYQAGALAAAOQABAUABAHQANA2AAAY");
	this.shape_27.setTransform(297.0369,70.537,1.3999,1.3999);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("Ag9ivQAVgCAOAJQAPAIAGATQAHAZADAMQAEASAAASQAAAlAMAkQANArAHAmQADAOAMAfQAKAdgIAQ");
	this.shape_28.setTransform(287.8773,50.0728,1.3999,1.3999);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhMB0QABgaAAgPQABgbgCgPQgIgrgEgWQgGgjAPgnQAQglAVgJQA7gaARA4QAEAOADAXQADAdABAHQACALAOA+QAGAYADAsQAEAdACAJQAFAWAKAJ");
	this.shape_29.setTransform(273.4003,41.1403,1.3999,1.3999);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(0.9,1,1).p("AhmgEQAJgRAPgMQAOgKAPgDQAbgFAPACQAYADAPAHQAhARAJAWQAEAHAGAXQAHATAMAC");
	this.shape_30.setTransform(252.3092,57.5828,1.3999,1.3999);

	this.instance_5 = new lib.ClipGroup();
	this.instance_5.parent = this;
	this.instance_5.setTransform(270.55,173.95,1.4,1.4,0,0,0,63.9,83);

	this.instance_6 = new lib.ClipGroup_6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(285.85,173.55,1.4,1.4,0,0,0,57.7,95.5);

	this.instance_7 = new lib.ClipGroup_5();
	this.instance_7.parent = this;
	this.instance_7.setTransform(273.4,167.95,1.4,1.4,0,0,0,48.8,87);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4}]}).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},9).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},19).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]},17).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_4}]},14).to({state:[]},1).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({_off:true},9).wait(8).to({_off:false},0).to({_off:true},19).wait(8).to({_off:false},0).to({_off:true},17).wait(8).to({_off:false},0).wait(14).to({_off:true},1).wait(16));

	// Layer_6
	this.instance_8 = new lib.Tween1("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-1.35,241.8,1,1,0,0,0,-86,58);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1).to({regX:0,regY:0,x:84.65,y:183.8},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({regX:-86,regY:58,x:-1.35,y:241.8},0).to({_off:true},1).wait(16));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-6.7,367.6,318.3);


// stage content:
(lib._160x600 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{});

	// Layer_12
	this.instance = new lib.Tween3("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(80,318.55,0.0567,0.0567,0,0,0,0.9,1.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(227).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.6804,scaleY:0.6804,y:318.5},5,cjs.Ease.get(1)).to({regY:0.2,scaleX:0.567,scaleY:0.567,y:318.55},5).wait(16));

	// Layer_11
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(80,259,0.0567,0.0567,0,0,0,0.9,1.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(222).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.6804,scaleY:0.6804,y:258.95},5,cjs.Ease.get(1)).to({regY:0.2,scaleX:0.567,scaleY:0.567,y:259},5).wait(21));

	// Layer_1
	this.instance_2 = new lib.ClipGroup_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(420.05,264.05,1.2,1.2,0,0,0,101.9,25.9);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(162).to({_off:false},0).to({regX:102,x:285.1,y:264},5,cjs.Ease.get(-1)).to({regX:101.9,x:150.05,y:264.05},5,cjs.Ease.get(1)).wait(1).to({regX:44.3,regY:35.2,x:80.9,y:275.2},0).wait(39).to({regX:101.9,regY:25.9,x:150.05,y:264.05},0).to({regX:102.1,regY:26.1,scaleX:0.24,scaleY:0.24,x:95,y:307.8},10,cjs.Ease.get(-1)).to({_off:true},1).wait(30));

	// _Clip_Group_
	this.instance_3 = new lib.ClipGroup_3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(88,297.1,0.12,0.12,0,0,0,110,39.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(97).to({_off:false},0).to({regX:109.7,regY:38.9,scaleX:1.2,scaleY:1.2,x:150,y:247.15},10,cjs.Ease.get(1)).wait(1).to({regX:50.4,regY:56.2,x:78.85,y:267.9},0).wait(54).to({regX:109.7,regY:38.9,x:150,y:247.15},0).to({regY:39,x:0.05,y:247.25},5,cjs.Ease.get(-1)).to({regY:38.9,x:-150,y:247.15},5,cjs.Ease.get(1)).to({_off:true},1).wait(80));

	// Symbol_3
	this.instance_4 = new lib.Symbol3("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(79.95,346.4,0.5601,0.5656,0,0,0,249.8,88.2);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(83).to({_off:false},0).to({regX:250.2,regY:88.1,scaleX:0.2912,scaleY:0.2911,rotation:720,x:80,y:346.35},19,cjs.Ease.get(1)).wait(1).to({regX:250,regY:88,x:79.95,y:346.3},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({regX:250.2,regY:88.1,x:80,y:346.35},0).to({regX:251.7,regY:88.5,scaleX:0.0582,scaleY:0.0582,rotation:1080,y:329.5},10,cjs.Ease.get(-1)).to({_off:true},1).wait(30));

	// Symbol_1
	this.instance_5 = new lib.Symbol1("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(75.9,309.55,0.5122,0.5121,0,0,0,167.1,28);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({_off:true},84).wait(169));

	// _Clip_Group__1
	this.instance_6 = new lib.ClipGroup_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(76.85,234.05,0.7248,0.7245,0,0,0,123.6,97);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({_off:true},84).wait(169));

	// Layer_13
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgGAHIACgNIALAAIgCANg");
	this.shape.setTransform(125.925,592.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgSAfIABgLIADAAQADAAACgDIACgEIgFgrIALAAIABARIAAAKIADgKIAGgRIAKAAIgTAtIgCAJQgEAHgJAAg");
	this.shape_1.setTransform(123.55,591.975);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAHAdIACgMIgTAAIgCAMIgJAAIADgWIAEAAQAFgHADgLIAEgRIAYAAIgGAjIAFAAIgEAWgAACgHQgCAIgEAGIAIAAIAFgaIgFAAIgCAMg");
	this.shape_2.setTransform(119.625,591.775);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AABAXIADgRIgEAAIgHARIgMAAIAKgUIgCgCQgCgCAAgFQAAgJAHgEQAEgDAGAAIAQAAIgHAtgAABgNQgCADAAAFIABADIADABIACAAIADgNIgDAAQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAg");
	this.shape_3.setTransform(115.975,591.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTAXIABgJQAEgBADgEIADgJIAFgWIAXAAIgHAtIgMAAIAGgkIgEAAQgCANgDALQgDAGgEAEQgDACgFAAIgCAAg");
	this.shape_4.setTransform(112.2,591.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQAXIAHgtIAaAAIgCAKIgOAAIgFAjg");
	this.shape_5.setTransform(109.25,591.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AABAXIADgUIADgGIgBAAIgDAFIgKASIgBADIgKAAIAHgtIALAAIgDATIgCAGIADgEIAKgSIABgDIAKAAIgHAtg");
	this.shape_6.setTransform(105.7,591.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgRAXIAIgtIAOAAQAGAAACACQAFACAAAGQAAAEgDAEQgCACgDABIADACQACACAAAEQAAAIgFAEQgEAEgGAAgAgEAPIADAAQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABgBQACgCAAgEIgBgDIgDgBIgCAAgAgBgEIACAAIAEgBQABgCAAgDIgBgEIgDAAIgCAAg");
	this.shape_7.setTransform(102.075,591.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLAUQgEgFAAgJQAAgOAFgIQAFgHAIAAQAFAAAEADQAFAFAAAJQAAALgEAIQgFALgKAAQgGAAgDgEgAgCgFIgCAQQAAABABABQAAABAAAAQAAABABAAQAAAAABAAQABAAACgEIABgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDAAgCAJg");
	this.shape_8.setTransform(96.5,591.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQAXIAHgtIAaAAIgCAKIgOAAIgFAjg");
	this.shape_9.setTransform(93.5,591.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgLAUQgEgFgBgJQABgOAFgIQAFgHAIAAQAFAAAEADQAEAFABAJQgBALgDAIQgFALgJAAQgHAAgDgEgAgBgFIgCAQQAAABAAABQAAABAAAAQAAABABAAQAAAAABAAQABAAABgEIACgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAgBAAQgCAAgBAJg");
	this.shape_10.setTransform(90.05,591.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgPAXIAHgtIALAAIgDARIAEAAQAFAAADACQAFADgBAHQAAAIgEAEQgFAEgHAAgAgDAPIACAAQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAgBQACgCAAgEIgBgEIgDgBIgCAAg");
	this.shape_11.setTransform(86.4,591.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAAAXIAEgTIgIAAIgDATIgMAAIAIgtIALAAIgCARIAHAAIADgRIALAAIgIAtg");
	this.shape_12.setTransform(82.95,591.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgbAXIAIgtIALAAIgGAjIAHAAIAGgjIAKAAIgGAjIAHAAIAGgjIAMAAIgIAtg");
	this.shape_13.setTransform(78.375,591.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgKAfIAHgsIALAAIgHAsgAgCgSIACgMIALAAIgCAMg");
	this.shape_14.setTransform(74.875,590.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAAAXIADgTIgHAAIgDATIgLAAIAHgtIALAAIgCARIAHAAIADgRIALAAIgIAtg");
	this.shape_15.setTransform(71.95,591.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgRAXIAIgtIAOAAQAGAAACACQAFACAAAGQAAAEgDAEQgCACgDABIADACQACACAAAEQAAAIgFAEQgEAEgGAAgAgEAPIADAAQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABgBQACgCAAgEIgBgDIgDgBIgCAAgAgBgEIACAAIAEgBQABgCAAgDIgBgEIgDAAIgCAAg");
	this.shape_16.setTransform(68.325,591.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgLAUQgFgFABgJQgBgOAGgIQAFgHAIAAQAGAAADADQAFAFgBAJQABALgEAIQgFALgKAAQgFAAgEgEgAgCgFIgCAQQABABAAABQAAABAAAAQAAABABAAQAAAAABAAQABAAACgEIABgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDAAgCAJg");
	this.shape_17.setTransform(64.8,591.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgLAVQgEgEAAgHIAJgBIACAEQAAABAAAAQAAAAABABQAAAAAAAAQABAAABAAQAAAAAAAAQABAAAAAAQAAgBAAAAQABAAAAgBQABgBAAgEIgBgDIgCgBIgBAAIgEAAIACgHIAEAAQAAAAAAAAQABAAAAgBQABAAAAAAQABAAAAgBQACgCAAgEIgBgCIgDgBQAAAAgBAAQAAAAAAAAQAAABgBAAQAAAAAAABIgCAEIgJgBQACgHADgEQAFgDAGAAQAGAAADADQADAEAAAFQAAAEgCADQgCADgEABIAAAAIAFACQACACAAAEQAAAIgHAFQgEADgGAAQgGAAgDgDg");
	this.shape_18.setTransform(61.35,591.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgLAUQgEgFAAgJQAAgOAFgIQAFgHAIAAQAFAAAEADQAFAFAAAJQAAALgEAIQgFALgKAAQgGAAgDgEgAgCgFIgCAQQAAABABABQAAABAAAAQAAABABAAQAAAAABAAQABAAACgEIABgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDAAgCAJg");
	this.shape_19.setTransform(56,591.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgQAXIAHgtIAaAAIgCAKIgOAAIgFAjg");
	this.shape_20.setTransform(53,591.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgLAUQgEgFgBgJQABgOAFgIQAFgHAIAAQAFAAAEADQAEAFABAJQgBALgDAIQgFALgJAAQgHAAgDgEgAgBgFIgCAQQAAABAAABQAAABAAAAQAAABABAAQAAAAABAAQABAAABgEIACgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAgBAAQgCAAgBAJg");
	this.shape_21.setTransform(49.55,591.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AABAfIADgUIACgHIAAAAIgDAGIgKASIgBADIgLAAIAIgtIALAAIgDASIgCAHIACgEIALgSIAAgDIALAAIgHAtgAgDgWQgCgDAAgEIAAgBIAHAAIAAABIABADIADABIADgBQABgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBIAJAAQgBAGgEADQgEADgGAAQgFAAgDgEg");
	this.shape_22.setTransform(45.875,590.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAHAdIACgMIgTAAIgCAMIgJAAIADgWIAEAAQAFgHADgLIAEgRIAYAAIgGAjIAFAAIgEAWgAACgHQgCAIgEAGIAIAAIAFgaIgFAAIgCAMg");
	this.shape_23.setTransform(39.725,591.775);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgKAfIAHgsIALAAIgHAsgAgCgSIACgMIALAAIgCAMg");
	this.shape_24.setTransform(37.275,590.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgRAXIAIgtIAOAAQAGAAACACQAFACAAAGQAAAEgDAEQgCACgDABIADACQACACAAAEQAAAIgFAEQgEAEgGAAgAgEAPIADAAQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAABgBQACgCAAgEIgBgDIgDgBIgCAAgAgBgEIACAAIAEgBQABgCAAgDIgBgEIgDAAIgCAAg");
	this.shape_25.setTransform(34.475,591.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AABAXIADgRIgEAAIgHARIgMAAIAKgUIgCgCQgCgCAAgFQAAgJAHgEQAEgDAGAAIAQAAIgHAtgAABgNQgCADAAAFIABADIADABIACAAIADgNIgDAAQgBAAAAAAQgBAAgBAAQAAAAAAABQgBAAAAAAg");
	this.shape_26.setTransform(142.025,581.475);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgMAUQgDgEAAgJQgBgMAFgIQAFgKAJAAQAGAAADADQAFAEgBAHIAAAEIgKAAIAAgDQAAgGgDAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAABAAAAQgBADgBAHIgCANQAAAEADAAQAEAAACgKIAJACQgCAJgEAEQgEAEgGAAQgGAAgEgEg");
	this.shape_27.setTransform(138.6,581.475);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AABAXIADgUIACgGIAAAAIgDAFIgKASIgBADIgLAAIAIgtIALAAIgDATIgCAGIADgEIAKgSIAAgDIAMAAIgIAtg");
	this.shape_28.setTransform(134.9,581.475);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgMAXIAHgjIgKAAIACgKIAdAAIgCAKIgJAAIgFAjg");
	this.shape_29.setTransform(131.85,581.475);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AABAXIADgRIgEAAIgHARIgMAAIAKgUIgCgCQgCgCAAgFQAAgJAHgEQAEgDAGAAIAQAAIgHAtgAABgNQgCADAAAFIABADIADABIACAAIADgNIgDAAQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAg");
	this.shape_30.setTransform(128.225,581.475);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAAAXIADgTIgHAAIgDATIgLAAIAHgtIALAAIgCARIAHAAIADgRIALAAIgIAtg");
	this.shape_31.setTransform(124.6,581.475);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgMAVQgDgEAAgHIAKgBIABAEQAAABAAAAQAAABABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAgBQABAAAAgBQABgBABgEIgBgDIgDgBIgBAAIgDAAIABgHIADAAQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAgBQABgCAAgEIAAgCIgCgBQgBAAgBAAQAAAAAAAAQAAAAgBABQAAAAgBABIgBAEIgKgBQACgHAFgEQAEgDAGAAQAFAAAEADQADAEAAAFQAAAEgCADQgCADgEABIAAAAIAFACQABACAAAEQABAIgHAFQgEADgGAAQgHAAgDgDg");
	this.shape_32.setTransform(121.05,581.475);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgKAfIAHgsIALAAIgHAsgAgCgSIACgMIALAAIgCAMg");
	this.shape_33.setTransform(118.775,580.625);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgSAfIAKg8IAKAAIgBAGQADgHAFAAQAEAAAEAEQACAEAAAIIgCAMIgDAKQgEAIgIAAQgDAAgCgEIgEATgAABgTIgBAEIgBAPIAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAAAQADABACgIQACgJAAgGIAAgEQgBgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBABg");
	this.shape_34.setTransform(115.7,582.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAHAdIACgMIgTAAIgCAMIgJAAIADgWIAEAAQAFgHADgLIAEgRIAYAAIgGAjIAFAAIgEAWgAACgHQgCAIgEAGIAIAAIAFgaIgFAAIgCAMg");
	this.shape_35.setTransform(111.925,582.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgKAfIAHgsIALAAIgHAsgAgCgSIACgMIALAAIgCAMg");
	this.shape_36.setTransform(109.475,580.625);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgRAXIAIgtIAOAAQAGAAACACQAFACAAAGQAAAEgDAEQgCACgDABIADACQACACAAAEQAAAIgFAEQgEAEgGAAgAgEAPIADAAQAAAAABAAQAAAAAAAAQAAAAABgBQAAAAABgBQACgCAAgEIgBgDIgDgBIgCAAgAgBgEIACAAIAEgBQABgCAAgDIgBgEIgDAAIgCAAg");
	this.shape_37.setTransform(106.675,581.475);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgLAUQgEgEAAgKQAAgLAFgJQAFgJAIAAQAFAAAEADQAEAEAAAKIAAAIIgTAAIgBAHQAAAGAEAAQABAAACgDIABgFIAKACQgCAIgFAEQgDADgFAAQgHAAgDgEgAgBgLIgBAHIAHAAIAAgHQAAgEgDAAQgCAAgBAEg");
	this.shape_38.setTransform(101.075,581.475);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AANAXQgDgDAAgGIAAgEIABgDQAAgBAAgBQAAgBgBAAQAAgBgBAAQgBAAAAAAIgCAAIgEAUIgKAAIADgUIgBAAQgDAAgBAEIgCAHQgDAGgDADIgGABIgDgBIABgJIABABIACgBIACgFIACgHQACgCAFAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBgBgBIABgCIAAgDQAAgBAAAAQAAgBAAAAQgBAAAAAAQAAgBAAAAIgBAAIABgHIADgBQAEABACACQAAAAABAAQAAABABAAQAAABAAABQAAAAAAABIgBAFIAAADQAAAEAEAAIABAAIADgRIAKAAIgDARIABAAIAEgBIACgEIABgHQABgEADgBQACgCAEAAIADABIgBAHIgBAAIgBACIgCAEIAAACQgCADgCACIgEACQADgBACACIABAEIgBAHQAAABABAAQAAABAAAAQAAAAAAAAQABABAAAAIACgBIgCAJIgEABIgFgBg");
	this.shape_39.setTransform(96.8,581.45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgLAUQgEgFAAgJQAAgOAFgIQAFgHAIAAQAFAAAEADQAFAFAAAJQAAALgEAIQgFALgJAAQgHAAgDgEgAgBgFIgDAQQAAABABABQAAABAAAAQAAABABAAQAAAAABAAQABAAABgEIACgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAgBAAQgCAAgBAJg");
	this.shape_40.setTransform(92.55,581.475);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAGAXIAFgbIACgIIgDAHIgLAcIgHAAIgBgbIAAgIIgBAIIgFAbIgJAAIAIgtIAQAAIAAAWIAAAFIAAAAIABgFIAIgWIAQAAIgIAtg");
	this.shape_41.setTransform(88.325,581.475);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgSAfIABgLIADAAQADAAACgDIACgEIgFgrIALAAIABARIAAAKIADgKIAGgRIAKAAIgTAtIgCAJQgEAHgJAAg");
	this.shape_42.setTransform(82.25,582.275);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgLAXIAFgjIgJAAIACgKIAdAAIgBAKIgKAAIgFAjg");
	this.shape_43.setTransform(79.35,581.475);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AADAXQgDgDAAgGIABgEIAAgDQAAgEgCAAIgCAAIgEAUIgLAAIAIgsIAKAAIgCARIACAAIACgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAIACgHQABgEACgBQACgCAFAAIADABIgBAHIgBAAIgCACIgBAEIgBACQgBADgCACIgEACQADgBACACIAAAEIAAAHQAAABABAAQAAABAAAAQAAAAAAAAQABABAAAAIABgBIgCAJIgDABIgGgBg");
	this.shape_44.setTransform(76.1,581.45);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgSAfIABgLIADAAQAEAAACgDIABgEIgGgrIANAAIAAARIAAAKIADgKIAGgRIAKAAIgSAtIgEAJQgDAHgJAAg");
	this.shape_45.setTransform(72.65,582.275);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAHAdIACgMIgTAAIgCAMIgJAAIADgWIAEAAQAFgHADgLIAEgRIAYAAIgGAjIAFAAIgEAWgAACgHQgCAIgEAGIAIAAIAFgaIgFAAIgCAMg");
	this.shape_46.setTransform(68.725,582.075);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgLAUQgFgFABgJQgBgOAGgIQAFgHAIAAQAGAAADADQAFAFgBAJQABALgEAIQgFALgKAAQgFAAgEgEgAgCgFIgCAQQAAABABABQAAABAAAAQAAABABAAQAAAAABAAQABAAACgEIABgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDAAgCAJg");
	this.shape_47.setTransform(65.25,581.475);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgSAfIAKg8IAKAAIgBAGQADgHAFAAQAFAAACAEQADAEAAAIIgCAMIgDAKQgEAIgHAAQgDAAgDgEIgEATgAABgTIgBAEIgBAPIAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAAAQADABACgIQACgJgBgGIAAgEQAAgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBABg");
	this.shape_48.setTransform(61.45,582.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AAAAXIAHgjIgIAAIgGAjIgLAAIAHgtIAeAAIgIAtg");
	this.shape_49.setTransform(58,581.475);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AABAXIADgRIgEAAIgHARIgMAAIAKgUIgCgCQgCgCAAgFQAAgJAHgEQAEgDAGAAIAQAAIgHAtgAABgNQgCADAAAFIABADIADABIACAAIADgNIgDAAQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAg");
	this.shape_50.setTransform(52.075,581.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAAAXIADgTIgHAAIgDATIgLAAIAHgtIALAAIgDARIAIAAIADgRIALAAIgIAtg");
	this.shape_51.setTransform(48.45,581.475);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAAAXIAEgTIgIAAIgDATIgMAAIAIgtIALAAIgCARIAHAAIADgRIALAAIgIAtg");
	this.shape_52.setTransform(44.7,581.475);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgLAUQgEgEAAgKQAAgLAFgJQAFgJAIAAQAFAAAEADQAEAEAAAKIAAAIIgTAAIgBAHQAAAGAEAAQABAAACgDIABgFIAKACQgCAIgFAEQgDADgFAAQgHAAgDgEgAgBgLIgBAHIAHAAIAAgHQAAgEgDAAQgCAAgBAEg");
	this.shape_53.setTransform(40.975,581.475);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AANAXQgDgDAAgGIAAgEIABgDQAAgBAAgBQAAgBgBAAQAAgBgBAAQgBAAgBAAIgBAAIgDAUIgLAAIAEgUIgCAAQgDAAgCAEIgBAHQgCAGgEADIgGABIgDgBIABgJIABABIADgBIABgFIACgHQACgCAFAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBgBAAgBIABgCIAAgDQAAgBAAAAQAAgBAAAAQgBAAAAAAQAAgBgBAAIgBAAIACgHIAEgBQADABACACQABAAAAAAQAAABABAAQAAABAAABQAAAAAAABIgBAFIAAADQAAAEAEAAIABAAIADgRIAKAAIgDARIABAAIAEgBIACgEIABgHQACgEACgBQACgCAEAAIADABIgBAHIgBAAIgCACIgBAEIAAACQgBADgDACIgEACQAEgBABACIABAEIAAAHQAAABAAAAQAAABAAAAQAAAAAAAAQABABAAAAIACgBIgCAJIgEABIgFgBg");
	this.shape_54.setTransform(36.7,581.45);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgOAUQgCgCAAgFQAAgHAEgFQAGgFAMAAIAAgDIABgDQAAgFgEAAQgDAAgBAIIgLgCQACgGADgDQAFgFAGAAQAGAAAEAEQADADAAAGIAAAIIgDAPIgBAJIAAABIgKAAIgBgDIAAgBIgCADQgCACgDAAQgGAAgDgEgAAAADQgEADAAAFIABADQAAABAAAAQABAAAAAAQAAABABAAQAAAAABAAQABAAACgFIABgGIABgEQgDAAgCACg");
	this.shape_55.setTransform(32.325,581.425);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgSAfIAKg8IAKAAIgBAGQADgHAFAAQAFAAACAEQADAEAAAIIgCAMIgDAKQgEAIgIAAQgDAAgCgEIgEATgAABgTIgBAEIgBAPIAAAEQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAAAQADABACgIQACgJAAgGIAAgEQgBgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBABg");
	this.shape_56.setTransform(28.5,582.2);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgOAdQgEgEAAgKQAAgFACgKIADgNQAFgLAHgEIAKgEIAKgCIgBAKIgIACIgLAFQgFADgCAIIAAAAIAFgEQACgBADAAQAFAAADADQAEADAAAIQAAAQgGAJQgFAHgHAAQgHAAgDgGgAgDAAIgCAHIgBAJIAAAFQAAABAAABQAAABAAABQABAAAAAAQABABAAAAQABAAAAgBQABAAAAAAQAAAAABgBQAAAAAAgBIABgHIACgJIAAgGIAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAABQgBAAAAABQAAABgBAAg");
	this.shape_57.setTransform(25.375,580.45);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgLAUQgFgFABgJQgBgOAGgIQAFgHAIAAQAGAAADADQAFAFgBAJQABALgEAIQgFALgKAAQgFAAgEgEgAgCgFIgBAQQAAABAAABQAAABAAAAQAAABABAAQAAAAABAAQABAAACgEIABgHIACgOQAAgBAAgBQAAgBgBAAQAAgBAAAAQgBAAAAAAQgDAAgCAJg");
	this.shape_58.setTransform(21.5,581.475);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgPAbQgEgFAAgHIAAgBIAMgCIAAABQAAADABACQABADAEABIADgCQACgDAAgGQAAgEgCgBQgBgBAAAAQgBAAAAgBQAAAAAAAAQgBAAgBAAIgDAAIABgJIAEAAQADAAACgCQACgDAAgGIgBgDIgDgBQgCgBgCADIgCAHIgLgCQACgJAGgFQAFgEAHAAQAGAAAEADQAEAEAAAHQAAAIgEAFQgDADgFAAQAEABACACQADADAAAGQAAALgHAGQgFAEgIAAQgIAAgEgFg");
	this.shape_59.setTransform(17.875,580.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},218).to({state:[]},1).wait(34));

	// BG
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#E21E26").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_60.setTransform(80.0011,300,0.5333,1);

	this.timeline.addTween(cjs.Tween.get(this.shape_60).wait(253));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-210.9,300,620.3,300);
// library properties:
lib.properties = {
	id: 'BCD38D56DBCA4145B433E66CB7772A04',
	width: 160,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/pack.png", id:"pack"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BCD38D56DBCA4145B433E66CB7772A04'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;